require("./_setup");
const test=require("node:test");const assert=require("node:assert");const fs=require("node:fs");const path=require("node:path");
const cfg=require("../src/config");const stats=require("../src/prospectStats");
const data={name:"Persistent Prospect",college:"Test U",position:"WR",height:"6'2\"",weight:"200",archetype:"Deep Threat",strength1:"Catching",strength2:"Speed",strength3:"Release",weakness1:"Run Block",weakness2:"Tackle",comparison:"Example"};

test("generated sheets persist in prospect-sheets.json",()=>{
  const sheet=stats.createProspectSheet(data,{messageId:"source-1",channelId:"source-channel",userId:"creator"});
  const saved=JSON.parse(fs.readFileSync(path.join(process.env.TML_DATA_DIR,"prospect-sheets.json"),"utf8"));
  const found=saved.sheets.find(s=>s.id===sheet.id);
  assert.ok(found);assert.strictEqual(found.name,"Persistent Prospect");assert.strictEqual(Object.keys(found.ratings).length,54);
});

test("full sheet is delivered to the requested channel in Discord-sized messages",async()=>{
  assert.strictEqual(cfg.PROSPECT_STATS_CHANNEL_ID,"1570602743834611924");
  const sheet=stats.generateProspectSheet(data);const sent=[];
  const channel={id:cfg.PROSPECT_STATS_CHANNEL_ID,guild:{members:{me:{}}},isTextBased:()=>true,permissionsFor:()=>null,
    send:async payload=>{sent.push(payload);return{id:`message-${sent.length}`};}};
  const client={channels:{fetch:async id=>{assert.strictEqual(id,"1570602743834611924");return channel;}}};
  await stats.publishProspectSheet(client,sheet,cfg.PROSPECT_STATS_CHANNEL_ID);
  assert.ok(sent.length>=1);assert.ok(sent.every(m=>m.content.length<=2000));
  assert.strictEqual(sheet.sheetChannelId,"1570602743834611924");assert.strictEqual(sheet.sheetMessageIds.length,sent.length);
  const text=sent.map(m=>m.content).join("\n");assert.ok(text.includes("Development Trait:"));assert.ok(text.includes("Throw Accuracy Deep (DAC):"));
});
