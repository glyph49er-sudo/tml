const fs = require("node:fs"); const os = require("node:os"); const path = require("node:path");
process.env.TML_DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), "tml-test-"));
process.env.WAITLIST_COACH_ROLE_ID = "coach"; process.env.WAITLIST_ROLE_ID = "wait";
