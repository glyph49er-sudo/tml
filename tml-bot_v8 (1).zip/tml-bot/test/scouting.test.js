require("./_setup");
const test = require("node:test"); const assert = require("node:assert");
const stats = require("../src/prospectStats");
const scouting = require("../src/scouting")._internal;
const data={name:"Scout Test",college:"Test U",position:"QB",height:"6'4\"",weight:"225",archetype:"Field General",strength1:"Throw Accuracy Short",strength2:"Throw Power",strength3:"Awareness",weakness1:"Speed",weakness2:"Carrying",comparison:"Example"};
const sheet=stats.generateProspectSheet(data); sheet.id="test-sheet"; stats.store.sheets.push(sheet);
const sequence=values=>{let i=0;return()=>values[i++%values.length];};

test("scout resets every two days at noon Los Angeles time",()=>{
  const before=scouting.scoutWindow(new Date("2026-01-01T19:59:00Z"));
  assert.strictEqual(before.start.toISOString(),"2025-12-30T20:00:00.000Z");
  assert.strictEqual(before.end.toISOString(),"2026-01-01T20:00:00.000Z");
  const open=scouting.scoutWindow(new Date("2026-01-02T20:00:00Z"));
  assert.strictEqual(open.start.toISOString(),"2026-01-01T20:00:00.000Z");
  assert.strictEqual(open.end.toISOString(),"2026-01-03T20:00:00.000Z");
  assert.strictEqual(scouting.losAngelesNoonUtc(Date.UTC(2026,6,3)/86400000).toISOString(),"2026-07-03T19:00:00.000Z");
});

test("normal scout reveals one random position-based attribute",()=>{
  const result=scouting.scout("normal-user",sheet,new Date("2026-01-02T21:00:00Z"),sequence([0.5,0.5,0]));
  assert.strictEqual(result.fullSheet,false);assert.strictEqual(result.developmentKnown,false);
  assert.strictEqual(result.code,stats.POSITIONS.QB.core[0]);assert.strictEqual(Object.keys(result.known.stats).length,1);
  const again=scouting.scout("normal-user",sheet,new Date("2026-01-02T22:00:00Z"),()=>0.5);
  assert.strictEqual(again.limited,true);
  const next=scouting.scout("normal-user",sheet,new Date("2026-01-03T20:00:00Z"),sequence([0.5,0.5,0]));
  assert.strictEqual(next.limited,false);
});

test("20% roll reveals and saves the development trait",()=>{
  const result=scouting.scout("dev-user",sheet,new Date("2026-01-02T21:00:00Z"),sequence([0.5,0.1999,0]));
  assert.strictEqual(result.developmentKnown,true);assert.strictEqual(result.known.developmentKnown,true);
  assert.ok(scouting.sheetLinesForUser("dev-user").some(line=>line.includes("Development Trait:")));
});

test("1% roll reveals and saves all 54 attributes",()=>{
  const result=scouting.scout("full-user",sheet,new Date("2026-01-02T21:00:00Z"),sequence([0.0099,0.5,0]));
  assert.strictEqual(result.fullSheet,true);assert.strictEqual(Object.keys(result.known.stats).length,54);
});

test("scout sheet contains only information that user gained",()=>{
  const lines=scouting.sheetLinesForUser("normal-user").join("\n");
  const first=stats.BY_CODE[stats.POSITIONS.QB.core[0]],other=stats.BY_CODE[stats.POSITIONS.QB.core[1]];
  assert.ok(lines.includes(`${first.name} (${first.code}):`));
  assert.ok(!lines.includes(`${other.name} (${other.code}):`));
});

test("reset-scout-sheets is admin-only and wipes sheets plus use limits",async()=>{
  const module=require("../src/scouting");
  scouting.store.users.adminTest={players:{},history:[]};scouting.store.uses.adminTest={window:"x",count:1};
  const interaction={commandName:"reset-scout-sheets",user:{id:"admin"},memberPermissions:{has:()=>false},reply:async payload=>{interaction.answer=payload;}};
  await module.handleCommand(interaction);
  assert.ok(interaction.answer.content.includes("administrator"));assert.ok(scouting.store.users.adminTest);
  interaction.memberPermissions.has=()=>true;
  await module.handleCommand(interaction);
  assert.deepStrictEqual(scouting.store.users,{});assert.deepStrictEqual(scouting.store.uses,{});
});
