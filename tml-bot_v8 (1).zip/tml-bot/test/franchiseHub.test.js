require("./_setup");
const test = require("node:test"); const assert = require("node:assert");
const fh = require("../src/franchiseHub");

test("parses common score layouts", () => {
  const text = fh.normalizeText("**Week 5 Results**\nRavens 24 vs 17 Steelers\nBAL 10 - 31 KC\nCowboys 21, Giants 14\nEagles vs Commanders 28-27");
  const g = fh.extractGames(text);
  assert.strictEqual(g.length, 4);
  assert.deepStrictEqual([g[0].leftTeam.name, g[0].leftScore, g[0].rightScore, g[0].rightTeam.name], ["Ravens", 24, 17, "Steelers"]);
  assert.deepStrictEqual([g[1].leftTeam.name, g[1].rightTeam.name, g[1].rightScore], ["Ravens", "Chiefs", 31]);
  assert.deepStrictEqual([g[2].leftTeam.name, g[2].leftScore, g[2].rightTeam.name, g[2].rightScore], ["Cowboys", 21, "Giants", 14]);
  assert.deepStrictEqual([g[3].leftTeam.name, g[3].leftScore, g[3].rightTeam.name, g[3].rightScore], ["Eagles", 28, "Commanders", 27]);
});
test("week matching", () => {
  assert.ok(fh.weekMatches("Week 5 Results", "5"));
  assert.ok(fh.weekMatches("WK5", "5"));
  assert.ok(!fh.weekMatches("Week 15 Results", "5"));
});
test("playoff week labels and aliases match the requested round", () => {
  for (const input of ["Wild Card", "wild-card", "wildcard"]) assert.ok(fh.weekMatches("Wild Card Results", input));
  assert.ok(fh.weekMatches("Divisional Round Results", "Divisional"));
  assert.ok(fh.weekMatches("Conference Championship Results", "Championship"));
  assert.ok(fh.weekMatches("NFC Championship Final", "Championship"));
  assert.ok(fh.weekMatches("AFC Championship Final", "Championship"));
  assert.ok(fh.weekMatches("NFC Championship Final", "NFC Championship"));
  assert.ok(fh.weekMatches("AFC Championship Final", "AFC Championship"));
  assert.ok(!fh.weekMatches("AFC Championship Final", "NFC Championship"));
  assert.ok(fh.weekMatches("Super Bowl Final", "Superbowl"));
  assert.ok(fh.weekMatches("Super Bowl Final", "SB"));
  assert.strictEqual(fh.weekLabel("Superbowl"), "Super Bowl");
});

test("no game -> nothing invented", () => {
  assert.strictEqual(fh.extractGames(fh.normalizeText("Week 5 schedule posted")).length, 0);
});

test("GOTW Final card (components v2) is readable", () => {
  const message = { content: "", embeds: [], components: [{ toJSON: () => ({ type: 17, components: [
    { type: 10, content: "🎉 GOTW winners: <@1> <@2>" },
    { type: 9, components: [{ type: 10, content: "# 🏆 <:commanders:123> Commanders defeat Browns 20–3\n💪 DECISIVE" }], accessory: { type: 11 } },
    { type: 10, content: "<:commanders:123> **Commanders** `20`\n<:browns:9> **Browns** `3`" },
    { type: 10, content: "-# GOTW Final · Week 16 · Season 2028 · Settled <t:1700000000:R>" }
  ] }) }] };
  const text = fh.messageText(message);
  assert.ok(fh.weekMatches(text, "16"));
  const g = fh.extractGames(text)[0];
  assert.ok(g);
  const w = g.leftScore > g.rightScore ? g.leftTeam : g.rightTeam;
  assert.strictEqual(w.name, "Commanders");
  assert.strictEqual(Math.max(g.leftScore, g.rightScore), 20);
});
