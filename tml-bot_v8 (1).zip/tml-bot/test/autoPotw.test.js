require("./_setup");
const test = require("node:test"); const assert = require("node:assert");
const claimer = require("../src/teamClaimer");
const { _internal } = require("../src/autoPotw");
const { commandJson } = require("../src/commands");
const D = require("../src/franchiseData");

test("EA team names map to the Discord user who claimed that TML team", () => {
  claimer.teamRoles.roles.r1 = { label: "Bills", category: "AFC" };
  claimer.teamClaims.claims.r1 = "user-bills";
  for (const n of ["Bills", "Buffalo Bills", "BUF", "buffalo bills"]) assert.strictEqual(_internal.ownerOfTeam(n), "user-bills", n);
  assert.strictEqual(_internal.ownerOfTeam("Jets"), null);
  assert.strictEqual(_internal.ownerOfTeam(""), null);
});

test("Madden link and auto-POTW commands are registered and admin-only", () => {
  const cmds = commandJson();
  for (const n of ["ea-connect", "ea-status", "ea-refresh", "ea-disconnect", "auto-potw"]) assert.ok(cmds.some(c => c.name === n), n);
});

test("conference awards pick the best AFC/NFC offense and defense performers", () => {
  const byId = { 1: { name: "Bills" }, 2: { name: "Eagles" } };
  const stats = {
    passing: [{ fullName: "QB One", teamId: 1, passYds: 300, passTDs: 3, passAtt: 30, passComp: 20 }, { fullName: "QB Two", teamId: 2, passYds: 250, passTDs: 2, passAtt: 28, passComp: 18 }],
    defense: [{ fullName: "DE One", teamId: 1, defSacks: 3, defTotalTackles: 5 }, { fullName: "LB Two", teamId: 2, defTotalTackles: 12, defInts: 1 }]
  };
  const out = D.conferenceAwards(D.playerPerformances(stats, byId), id => (id === 1 ? "AFC" : "NFC"));
  assert.deepStrictEqual(out.map(a => `${a.category}:${a.name}`).sort(), ["AFC Defense:DE One", "AFC Offense:QB One", "NFC Defense:LB Two", "NFC Offense:QB Two"]);
});
