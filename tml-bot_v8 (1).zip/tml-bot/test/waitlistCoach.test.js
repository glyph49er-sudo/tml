require("./_setup");
const test = require("node:test"); const assert = require("node:assert");
const tc = require("../src/teamClaimer");

function fakeGuild() {
  const roles = new Map([["coach", { id: "coach", name: "Waitlist Coach" }], ["wait", { id: "wait", name: "waitlist" }], ["ravens", { id: "ravens", name: "Ravens" }]]);
  const coll = m => Object.assign(m, { find: fn => [...m.values()].find(fn) });
  return { id: "g", roles: { cache: coll(roles) }, channels: { fetch: async () => null }, client: { user: { id: "bot" } } };
}
function fakeMember(guild, roleIds) {
  const set = new Set(roleIds);
  const cache = {
    has: id => set.has(id),
    filter: fn => { const arr = [...set].map(id => guild.roles.cache.get(id)).filter(Boolean).filter(fn); return { size: arr.length, first: () => arr[0], values: () => arr.values() }; }
  };
  return { id: "m1", guild, user: { tag: "m#1" }, roles: { cache, add: async r => set.add(r.id), remove: async r => set.delete(r.id) }, _set: set };
}
tc.teamRoles.roles.ravens = { label: "Ravens", category: "AFC" };

test("getting a team removes Waitlist Coach (and waitlist)", async () => {
  const g = fakeGuild(); const m = fakeMember(g, ["coach", "wait", "ravens"]);
  await tc._internal.onMemberGotTeam(m, "Ravens");
  assert.ok(!m._set.has("coach")); assert.ok(!m._set.has("wait"));
});

test("losing a team gives Waitlist Coach back", async () => {
  const g = fakeGuild(); const m = fakeMember(g, []);
  await tc._internal.onMemberLostTeam(m, "Ravens");
  assert.ok(m._set.has("coach"));
});

test("still holding a team -> no Waitlist Coach", async () => {
  const g = fakeGuild(); const m = fakeMember(g, ["ravens"]);
  await tc._internal.onMemberLostTeam(m, "Other");
  assert.ok(!m._set.has("coach"));
});

test("release clears the previous holder from claim data", async () => {
  tc._internal.setClaim("ravens", "m1");
  const g = fakeGuild(); const m = fakeMember(g, []);
  await tc._internal.handleTeamReleased(g, "ravens", m, "test");
  assert.strictEqual(tc.teamClaims.claims.ravens, undefined);
  assert.ok(m._set.has("coach"));
  const last = tc.teamClaims.history.at(-1);
  assert.strictEqual(last.action, "released"); assert.strictEqual(last.userId, "m1");
});
