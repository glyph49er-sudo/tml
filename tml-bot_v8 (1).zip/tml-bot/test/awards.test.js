require("./_setup");
const test = require("node:test"); const assert = require("node:assert");
const { _internal } = require("../src/awards");

test("Player of the Week keeps each user beside their +3 attribute and player", () => {
  const a = { week: "5", winners: ["a", "b", "c", "d"], submissions: {} };
  for (const [i, id] of a.winners.entries()) a.submissions[id] = { attribute: "Awareness", player: `Player ${i}` };
  const content = _internal.potwContent(a);
  assert.ok(!content.includes("submitted"));
  for (const [i, id] of a.winners.entries()) assert.ok(content.includes(`<@${id}> — **+3 Awareness** — **Player ${i}**`));
});

test("Player of the Week still identifies winners waiting to claim", () => {
  const content = _internal.potwContent({ week: "5", winners: ["a"], submissions: {} });
  assert.ok(content.includes("⏳ <@a> — click **Claim Award**"));
});

test("POTW rejects physical attributes, allows non-physical", () => {
  const { physicalMatch } = _internal;
  for (const a of ["Speed", "acceleration", "Agility", "STRENGTH", "Jumping", "Change-of-Direction", "change of direction", "Stamina", "Injury"]) assert.ok(physicalMatch(a), a);
  for (const a of ["Awareness", "Catching", "Throw Power", "Zone Coverage"]) assert.strictEqual(physicalMatch(a), null, a);
});

test("Game of the Week hides Game Info but keeps hub link and full reward", () => {
  const content = _internal.gotwContent({
    week: "Superbowl", winnerId: "winner", reason: "",
    game: { awayTeam: "Eagles", awayScore: 31, homeScore: 27, homeTeam: "Chiefs", winnerTeam: "Eagles", raw: "secret raw game info", sourceUrl: "https://discord.com/channels/1/2/3" },
    submission: { attribute: "Catching", player: "A. J. Brown" }
  });
  assert.ok(!content.includes("Game info") && !content.includes("secret raw game info"));
  assert.ok(content.includes("[FRANCHISE HUB post](https://discord.com/channels/1/2/3)"));
  assert.ok(content.includes("**Game of the Week (Super Bowl)**"));
  assert.ok(content.includes("<@winner> — **+3 Catching** — **A. J. Brown**"));
});

test("auto POTW shows the Madden award line under each winner, manual posts are unchanged", () => {
  const a = { week: "5", winners: ["a", "b"], submissions: {}, awardLines: { a: ["**AFC Offense:** **Josh Allen** (QB, Bills) — 20-30, 300 PASS YDS"] } };
  const lines = _internal.potwContent(a).split("\n");
  const i = lines.findIndex(l => l.includes("<@a>"));
  assert.ok(lines[i + 1].startsWith("> **AFC Offense:** **Josh Allen**"));
  assert.ok(lines[i + 2].includes("<@b>"));
  assert.ok(!_internal.potwContent({ week: "5", winners: ["a"], submissions: {} }).split("\n").some(l => l.startsWith("> ")));
});

test("auto POTW posts one Claim Award post for distinct owners and skips unclaimed teams", async () => {
  const sent = [];
  const channel = { id: "chan", send: async p => { sent.push(p); return { id: "msg1", channelId: "chan" }; } };
  const msg = await require("../src/awards").postAutoPotw(channel, 7, [
    { userId: "u1", line: "AFC Offense line" }, { userId: "u1", line: "AFC Defense line" }, { userId: null, line: "NFC Offense line" }, { userId: "u2", line: "NFC Defense line" }]);
  assert.strictEqual(msg.id, "msg1"); assert.strictEqual(sent.length, 1);
  assert.deepStrictEqual(sent[0].allowedMentions.users, ["u1", "u2"]);
  assert.ok(sent[0].content.includes("Week 7") && sent[0].content.includes("AFC Defense line") && !sent[0].content.includes("NFC Offense line"));
  await assert.rejects(() => require("../src/awards").postAutoPotw(channel, 7, [{ userId: null, line: "x" }]));
});
