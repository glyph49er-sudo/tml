// Attribute lists used by the Player / Game of the Week claim menus.
// Edit these lists if your league classifies attributes differently.
const PHYSICAL_ATTRIBUTES = [
  "Speed", "Acceleration", "Agility", "Strength", "Jumping",
  "Change of Direction", "Stamina", "Injury", "Toughness"
];

// Discord select menus hold max 25 options, so non-physical is split in two.
const NON_PHYSICAL_OFFENSE = [
  "Awareness", "Carrying", "Ball Carrier Vision", "Break Tackle", "Trucking", "Stiff Arm",
  "Spin Move", "Juke Move", "Catching", "Spectacular Catch", "Catch in Traffic",
  "Short Route Running", "Medium Route Running", "Deep Route Running", "Release",
  "Throw Power", "Short Accuracy", "Medium Accuracy", "Deep Accuracy",
  "Throw on the Run", "Throw Under Pressure", "Play Action", "Break Sack"
];
const NON_PHYSICAL_DEFENSE_ST = [
  "Run Block", "Pass Block", "Impact Blocking", "Lead Block", "Run Block Power",
  "Run Block Finesse", "Pass Block Power", "Pass Block Finesse",
  "Tackle", "Hit Power", "Pursuit", "Play Recognition", "Man Coverage", "Zone Coverage",
  "Press", "Block Shedding", "Power Moves", "Finesse Moves",
  "Kick Power", "Kick Accuracy", "Kick Return"
];
const NON_PHYSICAL_ATTRIBUTES = [...NON_PHYSICAL_OFFENSE, ...NON_PHYSICAL_DEFENSE_ST];

for (const list of [PHYSICAL_ATTRIBUTES, NON_PHYSICAL_OFFENSE, NON_PHYSICAL_DEFENSE_ST]) {
  if (list.length > 25) throw new Error("A select menu list has more than 25 options.");
}
for (const a of NON_PHYSICAL_ATTRIBUTES) if (PHYSICAL_ATTRIBUTES.includes(a)) throw new Error(`${a} is in both lists`);

module.exports = { PHYSICAL_ATTRIBUTES, NON_PHYSICAL_OFFENSE, NON_PHYSICAL_DEFENSE_ST, NON_PHYSICAL_ATTRIBUTES };
