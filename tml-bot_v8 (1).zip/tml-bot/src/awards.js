// Player of the Week (4 winners, typed +3 non-physical) and Game of the Week (+3 non-physical).
const {
  PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  StringSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle
} = require("discord.js");
const { readJson, writeJson } = require("./store");
const { NON_PHYSICAL_OFFENSE, NON_PHYSICAL_DEFENSE_ST } = require("./attributes");
const { findGame, weekLabel } = require("./franchiseHub");
const { TEAMS } = require("../teams");
const teamClaimer = require("./teamClaimer");
const { isAdmin, describeError } = require("./util");

const potw = readJson("potw", { awards: {} });
const gotw = readJson("gotw", { awards: {} });
const savePotw = () => writeJson("potw", potw);
const saveGotw = () => writeJson("gotw", gotw);
const newId = () => `${Date.now().toString(36)}${Math.floor(Math.random() * 1e4).toString(36)}`;
const cleanPlayer = s => String(s || "").replace(/[*_~`|]/g, "").replace(/\s+/g, " ").trim().slice(0, 60);
const weekNum = w => String(w).trim().replace(/^WK\s*/i, "").replace(/^WEEK\s*/i, "");

function playerModal(customId, title, label) {
  return new ModalBuilder().setCustomId(customId).setTitle(title.slice(0, 45)).addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("player").setLabel(label.slice(0, 45)).setPlaceholder("Player name").setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(60))
  );
}
const select = (customId, placeholder, list) => new ActionRowBuilder().addComponents(
  new StringSelectMenuBuilder().setCustomId(customId).setPlaceholder(placeholder).addOptions(list.map((a, i) => ({ label: a, value: String(i) })))
);

async function fetchAwardMessage(client, a) {
  const ch = await client.channels.fetch(a.channelId).catch(() => null);
  return ch?.isTextBased() ? ch.messages.fetch(a.messageId).catch(() => null) : null;
}

// ============================================================ Player of the Week
// POTW is a typed +3 NON-physical attribute; these physical ones are rejected.
const BANNED_PHYSICAL = [["speed","Speed"],["acceleration","Acceleration"],["accel","Acceleration"],["agility","Agility"],["strength","Strength"],["jumping","Jumping"],["jump","Jumping"],["changeofdirection","Change of Direction"],["cod","Change of Direction"],["stamina","Stamina"],["injury","Injury"]];
function physicalMatch(text) {
  const t = String(text || "").toLowerCase().replace(/[^a-z]/g, "");
  if (!t) return null;
  if (t === "spd" || t === "acc" || t === "agi" || t === "str" || t === "jmp" || t === "sta" || t === "inj" || t === "cod") return "short for a physical attribute";
  const hit = BANNED_PHYSICAL.find(([k]) => k.length > 3 && t.includes(k));
  return hit ? hit[1] : null;
}
function potwModal(id) {
  return new ModalBuilder().setCustomId(`potw_modal:${id}`).setTitle("Player of the Week — +3 Non-Physical").addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("attribute").setLabel("+3 NON-physical attribute").setPlaceholder("e.g. Awareness, Catching, Throw Power").setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(40)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("player").setLabel("Player you won Player of the Week for").setPlaceholder("Player name").setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(60))
  );
}
const potwRetry = a => [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`potw_claim:${a.id}`).setLabel("Try Again").setStyle(ButtonStyle.Primary))];
function potwContent(a) {
  return [
    `**Player of the Week — Week ${weekNum(a.week)}**`,
    "",
    ...a.winners.map(id => a.submissions[id]
      ? `✅ <@${id}> — **+3 ${a.submissions[id].attribute}** — **${a.submissions[id].player}**`
      : `⏳ <@${id}> — click **Claim Award**`).flatMap((line, n) => [line, ...(a.awardLines?.[a.winners[n]] || []).map(l => `> ${l}`)]),
    "",
    "Each winner types a **+3 NON-PHYSICAL attribute** and the player who earned it."
  ].join("\n");
}
const potwButtons = (a, disabled) => [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`potw_claim:${a.id}`).setLabel("Claim Award").setStyle(ButtonStyle.Primary).setDisabled(disabled))];

async function updatePotwMessage(client, a) {
  const msg = await fetchAwardMessage(client, a);
  if (!msg) throw new Error("I couldn't find the Player of the Week post to update (it may have been deleted).");
  const done = a.winners.every(id => a.submissions[id]);
  await msg.edit({ content: potwContent(a), components: done ? [] : potwButtons(a, false), allowedMentions: { parse: [] } });
}

// Auto Player of the Week (called by autoPotw.js): same post, same Claim Award button, with Madden's
// award line shown under each winner. entries: [{ userId, line }]; unclaimed teams (no userId) are skipped.
async function postAutoPotw(channel, week, entries) {
  const winners = [], awardLines = {};
  for (const e of entries) {
    if (!e.userId) continue;
    if (!winners.includes(e.userId)) winners.push(e.userId);
    (awardLines[e.userId] ||= []).push(e.line);
  }
  if (!winners.length) throw new Error("None of this week's award winners have a claimed team.");
  const a = { id: newId(), week, winners, awardLines, submissions: {}, auto: true, createdBy: null, createdAt: new Date().toISOString(), channelId: channel.id, messageId: null };
  const msg = await channel.send({ content: potwContent(a), components: potwButtons(a, false), allowedMentions: { users: winners } });
  a.messageId = msg.id;
  potw.awards[a.id] = a; savePotw();
  return msg;
}

// ============================================================ Game of the Week
function gotwContent(a) {
  const g = a.game;
  const s = a.submission;
  return [
    `**Game of the Week (${weekLabel(a.week)})**`,
    "",
    `**${g.awayTeam} ${g.awayScore} – ${g.homeScore} ${g.homeTeam}**`,
    `**Winner:** ${g.winnerTeam} — <@${a.winnerId}>`,
    `[FRANCHISE HUB post](${g.sourceUrl})`,
    a.reason ? `\n${a.reason}` : null,
    "",
    s ? `**+3 Reward:** <@${a.winnerId}> — **+3 ${s.attribute}** — **${s.player}**` : "**+3 Reward:** waiting for the winner's attribute and player"
  ].filter(x => x !== null).join("\n");
}
const gotwButtons = (a, disabled) => [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`gotw_claim:${a.id}`).setLabel("Claim Reward").setStyle(ButtonStyle.Success).setDisabled(disabled))];

// ============================================================ commands
const COMMAND_NAMES = ["player-of-the-week", "game-of-the-week"];

async function handleCommand(i) {
  if (!isAdmin(i)) return i.reply({ content: "You must be an administrator to use this command.", ephemeral: true });

  if (i.commandName === "player-of-the-week") {
    const week = i.options.getString("week", true);
    const users = [1, 2, 3, 4].map(n => i.options.getUser(`winner${n}`, true));
    const ids = users.map(u => u.id);
    if (new Set(ids).size !== 4) return i.reply({ content: "Please pick **four different** users.", ephemeral: true });
    if (users.some(u => u.bot)) return i.reply({ content: "Bots can't be Player of the Week winners.", ephemeral: true });
    const a = { id: newId(), week, winners: ids, submissions: {}, createdBy: i.user.id, createdAt: new Date().toISOString(), channelId: i.channelId, messageId: null };
    await i.deferReply({ ephemeral: true });
    const msg = await i.channel.send({ content: potwContent(a), components: potwButtons(a, false), allowedMentions: { users: ids } });
    a.messageId = msg.id;
    potw.awards[a.id] = a; savePotw();
    return i.editReply("Player of the Week posted.");
  }

  if (i.commandName === "game-of-the-week") {
    const week = i.options.getString("week", true);
    const user = i.options.getUser("winner", true);
    const reason = i.options.getString("reason") || "";
    await i.deferReply({ ephemeral: true });
    const member = await i.guild.members.fetch(user.id).catch(() => null);
    if (!member) return i.editReply(`${user} isn't in this server.`);
    const teams = [...teamClaimer.configuredTeamRolesOf(member).values()]
      .map(r => TEAMS.find(t => t.name === teamClaimer.teamRoles.roles[r.id]?.label)).filter(Boolean);
    if (!teams.length) return i.editReply(`${user} doesn't hold a TML team role, so I can't tell which game to look for. Assign their team first.`);

    const result = await findGame(i.client, week, teams);
    if (!result.found) return i.editReply(`❌ ${result.reason}\n\nNo Game of the Week post was created.`);
    const { game, message } = result;
    if (game.leftScore === game.rightScore) return i.editReply(`❌ The FRANCHISE HUB game for ${weekLabel(week)} is a tie (\`${game.raw}\`), so there is no winner. No post was created.`);
    const winnerTeam = game.leftScore > game.rightScore ? game.leftTeam : game.rightTeam;
    if (!teams.includes(winnerTeam)) {
      return i.editReply(`❌ The FRANCHISE HUB post shows **${winnerTeam.name}** won (\`${game.raw}\`), but ${user} holds **${teams.map(t => t.name).join(", ")}**. No post was created.`);
    }
    const a = {
      id: newId(), week, winnerId: user.id, reason, createdBy: i.user.id, createdAt: new Date().toISOString(),
      channelId: i.channelId, messageId: null, submission: null,
      game: {
        awayTeam: game.leftTeam.name, awayScore: game.leftScore, homeTeam: game.rightTeam.name, homeScore: game.rightScore,
        winnerTeam: winnerTeam.name, raw: game.raw.slice(0, 300), extra: null,
        sourceMessageId: message.id, sourceUrl: message.url
      }
    };
    const msg = await i.channel.send({ content: gotwContent(a), components: gotwButtons(a, false), allowedMentions: { users: [user.id] } });
    a.messageId = msg.id;
    gotw.awards[a.id] = a; saveGotw();
    return i.editReply(`Game of the Week posted from [this FRANCHISE HUB message](${message.url}).`);
  }
}

// ============================================================ components
const ownsComponent = id => /^(potw|gotw)_(claim|attr|modal)/.test(id);

async function handleComponent(i) {
  const [kind, ...rest] = i.customId.split(":");

  // ---- Player of the Week
  if (kind === "potw_claim" || kind === "potw_attr" || kind === "potw_modal") {
    const a = potw.awards[rest[0]];
    if (!a) return i.reply({ content: "This Player of the Week award is no longer available.", ephemeral: true });
    if (!a.winners.includes(i.user.id)) return i.reply({ content: "Only the Player of the Week winners can claim this award.", ephemeral: true });
    if (a.submissions[i.user.id]) return i.reply({ content: `You already submitted: **+3 ${a.submissions[i.user.id].attribute} ${a.submissions[i.user.id].player}**.`, ephemeral: true });

    if (kind === "potw_claim") return i.showModal(potwModal(a.id));
    if (kind === "potw_modal") {
      const attribute = cleanPlayer(i.fields.getTextInputValue("attribute"));
      const player = cleanPlayer(i.fields.getTextInputValue("player"));
      if (!attribute || !player) return i.reply({ content: "Please enter an attribute and a player name.", components: potwRetry(a), ephemeral: true });
      const bad = physicalMatch(attribute);
      if (bad) {
        return i.reply({ content: `❌ **${attribute}** is a physical attribute (${bad}). Player of the Week is a **+3 NON-PHYSICAL** attribute — Speed, Acceleration, Agility, Strength, Jumping, Change of Direction, Stamina and Injury are not allowed. Click **Try Again** and pick a non-physical attribute.`, components: potwRetry(a), ephemeral: true });
      }
      a.submissions[i.user.id] = { attribute, player, submittedAt: new Date().toISOString() };
      savePotw();
      await i.deferReply({ ephemeral: true });
      try { await updatePotwMessage(i.client, a); }
      catch (err) { return i.editReply(`Saved **+3 ${attribute} ${player}**, but I couldn't update the award post: ${describeError(err)}`); }
      const left = a.winners.filter(id => !a.submissions[id]).length;
      return i.editReply(`✅ Saved **+3 ${attribute} ${player}**.${left ? ` Waiting on ${left} more winner${left === 1 ? "" : "s"}.` : " All four winners are in — the post is complete."}`);
    }
  }

  // ---- Game of the Week
  if (kind === "gotw_claim" || kind === "gotw_attr" || kind === "gotw_modal") {
    const a = gotw.awards[rest[0]];
    if (!a) return i.reply({ content: "This Game of the Week award is no longer available.", ephemeral: true });
    if (i.user.id !== a.winnerId) return i.reply({ content: "Only the Game of the Week winner can claim this reward.", ephemeral: true });
    if (a.submission) return i.reply({ content: `You already claimed: **+3 ${a.submission.attribute} ${a.submission.player}**.`, ephemeral: true });
    const lists = { o: NON_PHYSICAL_OFFENSE, d: NON_PHYSICAL_DEFENSE_ST };

    if (kind === "gotw_claim") {
      return i.reply({
        content: "Which **+3 NON-PHYSICAL attribute** do you want? (Pick from either list.)",
        components: [select(`gotw_attr:${a.id}:o`, "Offense / ball skills", NON_PHYSICAL_OFFENSE), select(`gotw_attr:${a.id}:d`, "Blocking / defense / special teams", NON_PHYSICAL_DEFENSE_ST)],
        ephemeral: true
      });
    }
    if (kind === "gotw_attr") {
      const list = lists[rest[1]]; const idx = Number(i.values[0]);
      if (!list?.[idx]) return i.reply({ content: "That attribute isn't valid.", ephemeral: true });
      return i.showModal(playerModal(`gotw_modal:${a.id}:${rest[1]}:${idx}`, `+3 ${list[idx]}`, "Player you won Game of the Week for"));
    }
    if (kind === "gotw_modal") {
      const attribute = lists[rest[1]]?.[Number(rest[2])];
      const player = cleanPlayer(i.fields.getTextInputValue("player"));
      if (!attribute || !player) return i.reply({ content: "Please choose an attribute and enter a player name.", ephemeral: true });
      a.submission = { attribute, player, submittedAt: new Date().toISOString() };
      saveGotw();
      await i.deferReply({ ephemeral: true });
      const msg = await fetchAwardMessage(i.client, a);
      if (!msg) return i.editReply(`Saved **+3 ${attribute} ${player}**, but the award post no longer exists.`);
      try { await msg.edit({ content: gotwContent(a), components: gotwButtons(a, true), allowedMentions: { parse: [] } }); }
      catch (err) { return i.editReply(`Saved **+3 ${attribute} ${player}**, but I couldn't update the award post: ${describeError(err)}`); }
      return i.editReply(`✅ Saved **+3 ${attribute} ${player}**.`);
    }
  }
  return false;
}

module.exports = { COMMAND_NAMES, handleCommand, handleComponent, ownsComponent, postAutoPotw, _internal: { potwContent, gotwContent, physicalMatch } };
