// Madden link: connects TML to the Madden NFL 27 (PC) Connected Franchise through EA.
// Ported from the FDL bot's /ea-connect flow (same steps, same buttons/menus).
// Slash commands: /ea-connect /ea-status /ea-refresh /ea-disconnect (all admin-only).
// The saved EA session lives in data/ea-connection.json (owner-only file permissions).
const fs = require("node:fs");
const path = require("node:path");
const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, StringSelectMenuBuilder
} = require("discord.js");
const EA = require("./eaConnector");
const { DATA_DIR } = require("./store");
const { isAdmin } = require("./util");

const CONNECTION_PATH = path.join(DATA_DIR, "ea-connection.json");
const REFRESH_MS = 10 * 60 * 1000;
const PENDING_TTL = 10 * 60 * 1000;

let connection = null;
try { if (fs.existsSync(CONNECTION_PATH)) connection = JSON.parse(fs.readFileSync(CONNECTION_PATH, "utf8")); }
catch (err) { console.error("Could not read saved EA connection:", err?.message || err); }
const pending = new Map(); // adminId -> in-progress EA login

function saveConnection() {
  fs.mkdirSync(path.dirname(CONNECTION_PATH), { recursive: true });
  if (connection) fs.writeFileSync(CONNECTION_PATH, JSON.stringify(connection, null, 2), { mode: 0o600 });
  else if (fs.existsSync(CONNECTION_PATH)) fs.unlinkSync(CONNECTION_PATH);
}
const getConnection = () => connection;
const isConnected = () => Boolean(connection?.refreshToken && connection?.leagueId);

let syncPromise = null;
async function refreshConnection(reason = "manual") {
  if (!isConnected()) throw new Error("TML is not connected to an EA franchise yet. Run /ea-connect first.");
  if (syncPromise) return syncPromise;
  syncPromise = (async () => {
    try {
      const result = await EA.syncLeague(connection);
      connection.lastSyncReason = reason;
      saveConnection();
      return result;
    } catch (err) {
      connection.lastSyncError = err?.message || String(err);
      saveConnection();
      throw err;
    } finally { syncPromise = null; }
  })();
  return syncPromise;
}

function onReady() {
  if (isConnected()) refreshConnection("startup").catch(err => console.error("Initial EA roster sync failed:", err?.message || err));
  setInterval(() => {
    if (isConnected()) refreshConnection("scheduled").catch(err => console.error("Scheduled EA roster sync failed:", err?.message || err));
  }, REFRESH_MS).unref?.();
}

const COMMAND_NAMES = ["ea-connect", "ea-status", "ea-refresh", "ea-disconnect"];
const ownsComponent = id => /^(ea:begin:|eaCode:|eaPersona:|eaLeague:|eaRetryLeagues:)/.test(id);

const leagueMenu = (ownerId, leagues) => {
  const options = leagues.slice(0, 25).map((league, i) => ({
    label: String(league.leagueName || `Franchise ${i + 1}`).slice(0, 100),
    description: `${league.numMembers || 0} members • ${league.seasonText || "Connected Franchise"}`.slice(0, 100),
    value: String(league.leagueId)
  }));
  if (!options.length) throw new Error("EA login worked, but this account does not currently have any Connected Franchises.");
  return new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId(`eaLeague:${ownerId}`).setPlaceholder("Select the TML Connected Franchise").addOptions(options));
};

async function handleCommand(i) {
  const name = i.commandName;
  if (!isAdmin(i)) return i.reply({ content: "Only server administrators can use the Madden link commands.", ephemeral: true });

  if (name === "ea-connect") {
    const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`ea:begin:${i.user.id}`).setLabel("I've logged into EA").setStyle(ButtonStyle.Success));
    return i.reply({
      content: `**Connect TML to Madden NFL 27 (PC)**\n\n1. Open this EA login link in your browser: <${EA.EA_LOGIN_URL}>\n2. Sign into the EA account linked to the PC copy of Madden.\n3. EA will redirect to a local address that may show a connection error. That's expected. Copy the **entire URL from your browser address bar** (it contains the one-time code).\n4. Click the button below and paste that URL.\n\nTML stores the EA session tokens locally for automatic franchise checks. Do not send your EA password or any token to Discord or to anyone.`,
      components: [row], ephemeral: true
    });
  }
  if (name === "ea-status") {
    if (!connection?.leagueId) return i.reply({ content: "❌ TML is not connected to an EA franchise. Run `/ea-connect`.", ephemeral: true });
    const synced = connection.lastSync ? `<t:${Math.floor(connection.lastSync / 1000)}:R>` : "Not synced yet";
    return i.reply({ content: `**TML EA connection**\n• Platform: Madden NFL 27 PC\n• Franchise: **${connection.leagueName || connection.leagueId}**\n• Roster sync: ${synced}\n• Teams with an EA owner username: **${Number(connection.lastSyncOwners || 0)}/32**\n• Automatic refresh: every 10 minutes\n${connection.lastSyncError ? `\n⚠️ Last sync error: ${connection.lastSyncError}` : ""}`, ephemeral: true });
  }
  if (name === "ea-refresh") {
    if (!connection?.leagueId) return i.reply({ content: "❌ TML is not connected. Run `/ea-connect` first.", ephemeral: true });
    await i.deferReply({ ephemeral: true });
    try {
      const result = await refreshConnection("manual");
      return i.editReply(`✅ EA franchise data refreshed. **${result.teams.length} teams** checked; **${result.leagueOwners}** have an assigned EA username.`);
    } catch (err) {
      return i.editReply(`❌ EA refresh failed: ${err?.message || err}\n\nIf the EA session expired, run \`/ea-connect\` again.`);
    }
  }
  if (name === "ea-disconnect") {
    connection = null; saveConnection(); pending.delete(i.user.id);
    return i.reply({ content: "TML's saved EA connection has been removed.", ephemeral: true });
  }
}

async function handleComponent(i) {
  const parts = i.customId.split(":");
  const kind = i.customId.startsWith("ea:begin:") ? "ea:begin" : parts[0];
  const ownerId = parts[parts.length - 1];
  if (i.user.id !== ownerId) return i.reply({ content: "This EA connection session belongs to another administrator.", ephemeral: true });

  if (kind === "ea:begin" && i.isButton()) {
    const modal = new ModalBuilder().setCustomId(`eaCode:${ownerId}`).setTitle("Paste the EA redirect URL").addComponents(
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("redirectUrl").setLabel("Full URL from your browser address bar").setPlaceholder("http://127.0.0.1/success?code=...").setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(2000))
    );
    return i.showModal(modal);
  }

  if (kind === "eaCode" && i.isModalSubmit()) {
    await i.deferReply({ ephemeral: true });
    try {
      const auth = await EA.exchangeInitialCode(i.fields.getTextInputValue("redirectUrl"));
      pending.set(ownerId, { accessToken: auth.accessToken, personas: auth.personas, createdAt: Date.now() });
      const options = auth.personas.slice(0, 25).map((persona, n) => ({
        label: String(persona.displayName || persona.name || `PC Persona ${n + 1}`).slice(0, 100),
        description: `Madden 27 PC • ${persona.namespaceName}`.slice(0, 100),
        value: String(persona.personaId)
      }));
      const menu = new StringSelectMenuBuilder().setCustomId(`eaPersona:${ownerId}`).setPlaceholder("Select your Madden PC persona").addOptions(options);
      return i.editReply({ content: "✅ EA account recognized. Select the Madden PC persona that owns the franchise:", components: [new ActionRowBuilder().addComponents(menu)] });
    } catch (err) {
      console.error("EA initial authorization failed:", err?.message || err);
      return i.editReply(`❌ EA authorization failed: ${err?.message || err}\n\nRun \`/ea-connect\` and try a fresh login link. The EA login code can only be used once.`);
    }
  }

  if (kind === "eaPersona" && i.isStringSelectMenu()) {
    await i.deferUpdate();
    try {
      const p = pending.get(ownerId);
      if (!p || Date.now() - p.createdAt > PENDING_TTL) throw new Error("This EA setup session expired. Run /ea-connect again.");
      const persona = p.personas.find(x => String(x.personaId) === i.values[0]);
      if (!persona) throw new Error("That Madden persona was not found in the pending EA login.");
      const token = await EA.getPersonaToken(p.accessToken, persona);
      // Keep the authorized token before loading franchises so a temporary EA outage can be retried without a new login.
      pending.set(ownerId, { ...p, token, persona, createdAt: Date.now() });
      const leagues = await EA.getLeagues(token);
      pending.set(ownerId, { ...p, token, persona, leagues, createdAt: Date.now() });
      return i.editReply({ content: "✅ Madden PC persona authorized. Select the TML Connected Franchise:", components: [leagueMenu(ownerId, leagues)] });
    } catch (err) {
      console.error("EA persona selection failed:", err?.message || err);
      const canRetry = Boolean(pending.get(ownerId)?.token);
      const retryRow = canRetry ? [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`eaRetryLeagues:${ownerId}`).setLabel("Retry franchise lookup").setStyle(ButtonStyle.Primary))] : [];
      return i.editReply({ content: `❌ Could not load your Madden franchises: ${err?.message || err}.${canRetry ? "\n\nYour EA authorization is still saved temporarily. Use the button below to retry without signing in again." : "\n\nRun /ea-connect again to restart EA authorization."}`, components: retryRow });
    }
  }

  if (kind === "eaRetryLeagues" && i.isButton()) {
    await i.deferUpdate();
    try {
      const p = pending.get(ownerId);
      if (!p?.token || Date.now() - p.createdAt > PENDING_TTL) throw new Error("The temporary EA authorization expired. Run /ea-connect again.");
      const leagues = await EA.getLeagues(p.token);
      pending.set(ownerId, { ...p, leagues, createdAt: Date.now() });
      return i.editReply({ content: "✅ Madden PC persona authorized. Select the TML Connected Franchise:", components: [leagueMenu(ownerId, leagues)] });
    } catch (err) {
      return i.editReply({ content: `❌ Still could not load your Madden franchises: ${err?.message || err}`, components: [] });
    }
  }

  if (kind === "eaLeague" && i.isStringSelectMenu()) {
    await i.deferUpdate();
    try {
      const p = pending.get(ownerId);
      if (!p?.token) throw new Error("Your EA setup session expired. Run /ea-connect again.");
      const league = p.leagues.find(l => String(l.leagueId) === i.values[0]);
      if (!league) throw new Error("That Connected Franchise was not found in the pending EA session.");
      connection = {
        ...p.token, leagueId: Number(league.leagueId), leagueName: String(league.leagueName || "Connected Franchise"),
        connectedAt: Date.now(), connectedBy: ownerId, teams: [], lastSync: 0, lastSyncOwners: 0
      };
      saveConnection();
      const result = await refreshConnection("initial-connect");
      pending.delete(ownerId);
      return i.editReply({ content: `✅ **TML is connected to Madden NFL 27 PC!**\n\nFranchise: **${connection.leagueName}**\nTeams found: **${result.teams.length}/32**\nTeams with an EA username: **${result.leagueOwners}**\n\nThe franchise data refreshes automatically every 10 minutes.`, components: [] });
    } catch (err) {
      console.error("EA franchise selection failed:", err?.message || err);
      return i.editReply({ content: `❌ The franchise was selected, but the first EA sync failed: ${err?.message || err}\n\nThe connection details were saved. You can try /ea-refresh or reconnect with /ea-connect.`, components: [] });
    }
  }
  return false;
}

module.exports = { COMMAND_NAMES, handleCommand, handleComponent, ownsComponent, onReady, getConnection, saveConnection, isConnected, refreshConnection };
