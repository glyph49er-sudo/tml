// Finds a week's game in the FRANCHISE HUB channel and extracts the matchup.
// Text normalization and the "Team 35 vs 26 Team" parser are ported from the
// FDL bot's Snallabot score search; extra patterns were added for other common
// layouts. Nothing is ever invented: if no message/game is found we say so.
const cfg = require("./config");
const { TEAMS, teamAliases } = require("../teams");

const esc = s => String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const PLAYOFFS = [
  { key: "WILD_CARD", label: "Wild Card", match: /^WILDCARD$/ },
  { key: "DIVISIONAL", label: "Divisional", match: /^(?:DIVISIONAL|DIVISIONALROUND|DIVISIONALPLAYOFFS?)$/ },
  { key: "NFC_CHAMPIONSHIP", label: "NFC Championship", match: /^NFCCHAMPIONSHIP$/ },
  { key: "AFC_CHAMPIONSHIP", label: "AFC Championship", match: /^AFCCHAMPIONSHIP$/ },
  { key: "CHAMPIONSHIP", label: "Championship", match: /^(?:CHAMPIONSHIP|CONFERENCECHAMPIONSHIPS?|CHAMPIONSHIPROUND)$/ },
  { key: "SUPER_BOWL", label: "Super Bowl", match: /^(?:SUPERBOWL|SB)$/ }
];
const playoff = w => PLAYOFFS.find(p => p.match.test(String(w || "").toUpperCase().replace(/[^A-Z0-9]/g, ""))) || null;
const weekLabel = w => {
  const p = playoff(w); if (p) return p.label;
  const x = String(w).trim().replace(/^week\s*/i, ""); return /^WK/i.test(x) ? x.toUpperCase() : `WK${x}`;
};

function normalizeText(text) {
  return String(text || "")
    .replace(/<a?:([^:>]+):\d+>/g, " $1 ")      // keep custom emoji names (often team names)
    .replace(/<@[!&]?\d+>/g, " ").replace(/<#\d+>/g, " ")
    .replace(/<t:\d+(?::[tTdDfFR])?>/g, " ")
    .replace(/[\u200B-\u200D\uFEFF]/g, "")
    .replace(/[\u00A0\u1680\u2000-\u200A\u202F\u205F\u3000]/g, " ")
    .replace(/\r/g, "").replace(/[*_~`|>#]/g, "")
    .replace(/[ \t]+/g, " ").replace(/\n\s*/g, "\n").trim();
}

function messageText(message) {
  const parts = [message.content || ""];
  for (const e of message.embeds || []) {
    parts.push(e.author?.name, e.title, e.description);
    for (const f of e.fields || []) { parts.push(f.name, f.value, `${f.name} ${f.value}`); }
    parts.push(e.footer?.text);
  }
  // Newer bots (like the one posting GOTW Final cards) use Discord's
  // "Components V2" layout: the text lives in components, not content/embeds.
  const walk = c => {
    if (!c) return;
    const d = typeof c.toJSON === "function" ? c.toJSON() : (c.data ? { ...c.data, components: c.components } : c);
    if (typeof d.content === "string") parts.push(d.content);
    if (d.label) parts.push(d.label);
    for (const k of ["components", "accessory"]) {
      const v = d[k] ?? c[k];
      if (Array.isArray(v)) v.forEach(walk); else if (v && typeof v === "object") walk(v);
    }
  };
  (message.components || []).forEach(walk);
  return normalizeText(parts.filter(Boolean).join("\n"));
}

function weekMatches(text, week) {
  const p = playoff(week);
  if (p) {
    const compact = String(text || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
    const nfc = compact.includes("NFCCHAMPIONSHIP"), afc = compact.includes("AFCCHAMPIONSHIP");
    const generic = /CONFERENCECHAMPIONSHIP|CHAMPIONSHIPROUND/.test(compact) || /(?:^|[^A-Z])CHAMPIONSHIP/.test(String(text || "").toUpperCase().replace(/(?:NFC|AFC)\s+CHAMPIONSHIP/g, ""));
    if (p.key === "NFC_CHAMPIONSHIP") return nfc || (generic && !afc);
    if (p.key === "AFC_CHAMPIONSHIP") return afc || (generic && !nfc);
    if (p.key === "CHAMPIONSHIP") return nfc || afc || generic;
    if (p.key === "WILD_CARD") return compact.includes("WILDCARD");
    if (p.key === "DIVISIONAL") return compact.includes("DIVISIONAL");
    if (p.key === "SUPER_BOWL") return compact.includes("SUPERBOWL");
    return false;
  }
  const n = String(week).trim().replace(/^WK\s*/i, "").replace(/^WEEK\s*/i, "");
  if (!n) return false;
  return new RegExp(`(?:\\bWK|\\bWEEK)\\s*#?\\s*${esc(n)}(?!\\d)`, "i").test(text);
}

function teamAppears(text, team) {
  return teamAliases(team).some(a => new RegExp(`(?:^|[^a-z0-9])${esc(a)}(?:$|[^a-z0-9])`, "i").test(text));
}
function teamIn(text) { return TEAMS.filter(t => teamAppears(text, t)); }

const stripNote = s => String(s || "").replace(/\s*\([^)]*\)\s*$/, "").trim();

function extractGames(text) {
  const games = [];
  const lines = text.split("\n").map(x => x.trim()).filter(Boolean);
  // Two consecutive lines "Commanders 20" / "Browns 3" (scoreboard cards).
  for (let k = 0; k + 1 < lines.length; k++) {
    const a = stripNote(lines[k]).match(/^(.*?[a-z].*?)\s+(\d{1,3})$/i), b = stripNote(lines[k + 1]).match(/^(.*?[a-z].*?)\s+(\d{1,3})$/i);
    if (a && b) games.push({ left: a[1], leftScore: +a[2], right: b[1], rightScore: +b[2], raw: `${lines[k]} / ${lines[k + 1]}` });
  }
  for (const raw of lines) {
    const line = stripNote(raw);
    let m;
    // Commanders defeat Browns 20-3   |   Ravens beat Steelers 24 - 17
    if ((m = line.match(/^(.*?)\s+(?:defeats?|beats?|tops?|edges?|over|def\.?|routs?|downs?)\s+(.*?)[\s,:]+(\d{1,3})\s*[-–—:]\s*(\d{1,3})$/i))) { games.push({ left: m[1], leftScore: Math.max(+m[3], +m[4]), right: m[2], rightScore: Math.min(+m[3], +m[4]), raw }); continue; }
    // Ravens 24 vs 17 Steelers   |   Ravens 24 - 17 Steelers   |  Ravens 24 17 Steelers
    if ((m = line.match(/^(.*?)\s+(\d{1,3})\s*(?:vs\.?|@|at|[-–—:])?\s*(\d{1,3})\s+(.*?)$/i))) games.push({ left: m[1], leftScore: +m[2], right: m[4], rightScore: +m[3], raw });
    // Ravens 24, Steelers 17   |   Ravens 24 @ Steelers 17
    else if ((m = line.match(/^(.*?)\s+(\d{1,3})\s*(?:,|vs\.?|@|at|[-–—])\s*(.*?)\s+(\d{1,3})$/i))) games.push({ left: m[1], leftScore: +m[2], right: m[3], rightScore: +m[4], raw });
    // Ravens vs Steelers 24-17   |   Ravens @ Steelers: 24 - 17
    else if ((m = line.match(/^(.*?)\s+(?:vs\.?|@|at)\s+(.*?)[\s:]+(\d{1,3})\s*[-–—:]\s*(\d{1,3})$/i))) games.push({ left: m[1], leftScore: +m[3], right: m[2], rightScore: +m[4], raw });
  }
  return games
    .map(g => ({ ...g, leftTeam: teamIn(g.left)[0] || null, rightTeam: teamIn(g.right)[0] || null }))
    .filter(g => g.leftTeam && g.rightTeam && g.leftTeam !== g.rightTeam);
}

// Returns { found:true, game, message } or { found:false, reason }.
async function findGame(client, week, teams, { maxMessages = 3000 } = {}) {
  const channel = await client.channels.fetch(cfg.FRANCHISE_HUB_CHANNEL_ID).catch(() => null);
  if (!channel?.isTextBased() || !channel.messages?.fetch) {
    return { found: false, reason: `I can't read the FRANCHISE HUB channel <#${cfg.FRANCHISE_HUB_CHANNEL_ID}>. Give me View Channel + Read Message History there.` };
  }
  let before, checked = 0, weekMessages = 0;
  while (checked < maxMessages) {
    const batch = await channel.messages.fetch({ limit: 100, ...(before ? { before } : {}) }).catch(() => null);
    if (!batch?.size) break;
    for (const m of batch.values()) {
      checked++;
      if (!m.author?.bot) continue; // FRANCHISE HUB posts are bot messages
      const text = messageText(m);
      if (!text || !weekMatches(text, week)) continue;
      weekMessages++;
      const game = extractGames(text).find(g => teams.some(t => t === g.leftTeam || t === g.rightTeam));
      if (game) return { found: true, game, message: m };
    }
    before = batch.last().id;
    if (batch.size < 100) break;
  }
  const names = teams.map(t => t.name).join(" / ");
  return {
    found: false,
    reason: weekMessages
      ? `I found ${weekMessages} FRANCHISE HUB message(s) for **${weekLabel(week)}**, but none contained a readable game for **${names}**. The game message could not be located.`
      : `I could not locate a FRANCHISE HUB bot message for **${weekLabel(week)}** in <#${cfg.FRANCHISE_HUB_CHANNEL_ID}> (checked ${checked} messages).`
  };
}

module.exports = { findGame, extractGames, weekMatches, messageText, normalizeText, weekLabel };
