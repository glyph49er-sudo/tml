const { PermissionFlagsBits } = require("discord.js");

let rateLimitUntil = 0;
function rateLimitSecondsLeft() { return Math.max(0, Math.ceil((rateLimitUntil - Date.now()) / 1000)); }
function extractRetryAfterSeconds(err) {
  const message = err?.message || String(err);
  const match = message.match(/[Rr]etry after ([\d.]+)/);
  if (match) return Math.ceil(Number(match[1]));
  if (err?.retryAfter) return Math.ceil(Number(err.retryAfter));
  return null;
}
function registerRateLimit(err) {
  const seconds = extractRetryAfterSeconds(err);
  if (seconds == null) return null;
  const until = Date.now() + seconds * 1000;
  if (until > rateLimitUntil) rateLimitUntil = until;
  return seconds;
}
function rateLimitNotice(prefix) {
  const seconds = rateLimitSecondsLeft();
  return `⏳ ${prefix} Please wait **${seconds} second${seconds === 1 ? "" : "s"}** and then try again.`;
}
function describeError(err) {
  const message = err?.message || String(err);
  const retry = message.match(/[Rr]etry after ([\d.]+)/);
  if (retry || /rate limit/i.test(message)) {
    if (retry) {
      const seconds = Math.ceil(Number(retry[1]));
      return `Discord is rate limiting us right now. Please wait ${seconds} second${seconds === 1 ? "" : "s"} and try again.`;
    }
    return "Discord is rate limiting us right now. Please wait a few seconds and try again.";
  }
  if (err?.code === 50013) return "I don't have permission to do that — my bot role must be above the team/waitlist roles (and I need Manage Roles + Manage Nicknames), and I need access to the channel.";
  if (err?.code === 50001) return "I don't have access to do that here.";
  if (err?.code === 10011) return "That role no longer exists.";
  if (err?.code === 10007) return "I couldn't find that member in this server.";
  if (err?.code === 10008) return "That message no longer exists.";
  return message;
}
function isAdmin(i) { return Boolean(i.memberPermissions?.has(PermissionFlagsBits.Administrator)); }

// Split long text into Discord-sized chunks on line boundaries.
function chunkLines(header, lines, limit = 1900) {
  const chunks = [];
  let chunk = header;
  for (const line of lines) {
    if ((chunk + line + "\n").length > limit) { chunks.push(chunk); chunk = ""; }
    chunk += line + "\n";
  }
  if (chunk) chunks.push(chunk);
  return chunks;
}

async function safeReply(i, payload) {
  if (!i.isRepliable()) return;
  const body = typeof payload === "string" ? { content: payload } : payload;
  try {
    if (i.deferred) return await i.editReply(body);
    if (i.replied) return await i.followUp({ ...body, ephemeral: true });
    return await i.reply({ ...body, ephemeral: true });
  } catch (err) { console.error("Could not reply to interaction:", err?.message || err); }
}

module.exports = { rateLimitSecondsLeft, registerRateLimit, rateLimitNotice, describeError, isAdmin, chunkLines, safeReply };
