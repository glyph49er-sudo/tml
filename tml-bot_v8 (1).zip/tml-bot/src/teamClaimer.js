// TML Team Claimer. Ported from the Team Claimer index.js. Behavior kept:
// one team per member / one member per team (no screenshot verification in TML),
// waitlist, role assignment, release workflows.
// TML additions: Waitlist Coach role swap, team-opened announcements with a
// configurable waitlist role, open-teams channel refresh, separate TML data files.
const {
  PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder
} = require("discord.js");
const { TEAMS } = require("../teams");
const cfg = require("./config");
const { readJson, writeJson } = require("./store");
const { rateLimitSecondsLeft, registerRateLimit, rateLimitNotice, describeError, isAdmin, chunkLines } = require("./util");

// ---------------------------------------------------------------- data
const teamRoles = readJson("teamRoles", { roles: {} });          // roleId -> { label, emoji, roleName, category }
const teamClaims = readJson("teamClaims", { claims: {}, history: [] }); // roleId -> userId
const waitlist = readJson("waitlist", { members: {}, announcements: [] });

const saveRoles = () => writeJson("teamRoles", teamRoles);
const saveClaims = () => { teamClaims.history = teamClaims.history.slice(-2000); writeJson("teamClaims", teamClaims); };
const saveWaitlist = () => { waitlist.announcements = waitlist.announcements.slice(-500); writeJson("waitlist", waitlist); };


// Open-teams refresh hook (set by index.js) so this module has no circular import.
let onTeamsChanged = () => {};
function setTeamsChangedHook(fn) { onTeamsChanged = fn; }
function teamsChanged(guild) { try { onTeamsChanged(guild); } catch (e) { console.error("teamsChanged hook:", e); } }

// ---------------------------------------------------------------- helpers
function getRoleByIdOrName(guild, id, name) {
  if (id) return guild.roles.cache.get(id) || null;
  return guild.roles.cache.find(r => r.name.toLowerCase() === String(name).toLowerCase()) || null;
}
const getWaitlistRole = guild => getRoleByIdOrName(guild, cfg.WAITLIST_ROLE_ID, cfg.WAITLIST_ROLE_NAME);
const getCoachRole = guild => getRoleByIdOrName(guild, cfg.WAITLIST_COACH_ROLE_ID, cfg.WAITLIST_COACH_ROLE_NAME);

function resolveGuildEmoji(guild, name) {
  if (!name) return "🏈";
  const match = String(name).match(/^:([^:]+):$/);
  if (match) {
    const wanted = match[1].toLowerCase();
    const emoji = guild.emojis.cache.find(e => e.name.toLowerCase() === wanted);
    if (emoji) return `<:${emoji.name}:${emoji.id}>`;
    return "🏈"; // unknown :name: is not valid button emoji; fall back safely
  }
  return name;
}
function teamButton(guild, roleId, data) {
  return new ButtonBuilder()
    .setCustomId(`claim:${roleId}`)
    .setLabel(data.label || data.roleName || "Claim")
    .setStyle(data.category === "AFC" ? ButtonStyle.Danger : ButtonStyle.Primary)
    .setEmoji(resolveGuildEmoji(guild, data.emoji));
}
const configuredTeamRolesOf = member => member.roles.cache.filter(r => Boolean(teamRoles.roles[r.id]));
const hasTeamRole = member => configuredTeamRolesOf(member).size > 0;
const getConfiguredTeamRoleIds = () => Object.keys(teamRoles.roles);
const claimedUserId = roleId => teamClaims.claims[roleId] || null;
function teamLabel(roleId) { return teamRoles.roles[roleId]?.label || roleId; }

function setClaim(roleId, userId) {
  if (teamClaims.claims[roleId] === userId) return;
  teamClaims.claims[roleId] = userId;
  teamClaims.history.push({ action: "claimed", roleId, team: teamLabel(roleId), userId, at: new Date().toISOString() });
  saveClaims();
}
// Removes the previous holder from the claim data and records who it was.
function clearClaim(roleId, reason = "released") {
  const prev = teamClaims.claims[roleId];
  if (!prev) return null;
  delete teamClaims.claims[roleId];
  teamClaims.history.push({ action: "released", roleId, team: teamLabel(roleId), userId: prev, reason, at: new Date().toISOString() });
  saveClaims();
  return prev;
}

const pendingClaims = new Map(); // `${guildId}:${userId}` -> { roleId, username, createdAt } (in memory by design)
const pendingKey = (g, u) => `${g}:${u}`;
const clearPending = (g, u) => pendingClaims.delete(pendingKey(g, u));

const guildLocks = new Set();
async function withGuildLock(guildId, fn) {
  while (guildLocks.has(guildId)) await new Promise(r => setTimeout(r, 50));
  guildLocks.add(guildId);
  try { return await fn(); } finally { guildLocks.delete(guildId); }
}

let memberCacheReady = false, lastMemberFetch = 0;
async function ensureMembers(guild, { force = false } = {}) {
  if (!guild) return false;
  if (!force && memberCacheReady && Date.now() - lastMemberFetch < 60_000) return true;
  try {
    await guild.members.fetch();
    memberCacheReady = true; lastMemberFetch = Date.now();
    return true;
  } catch (err) {
    console.error("Could not fetch guild members:", err?.message || err);
    return memberCacheReady;
  }
}

async function findRoleHolder(guild, role) {
  const recorded = claimedUserId(role.id);
  if (recorded) {
    const member = await guild.members.fetch(recorded).catch(() => null);
    if (member && member.roles.cache.has(role.id)) return { holder: member, holderId: recorded, verified: true };
    clearClaim(role.id, "stale"); // the member left or lost the role
  }
  const ok = await ensureMembers(guild);
  const cached = role.members.first() || null;
  if (cached) { setClaim(role.id, cached.id); return { holder: cached, holderId: cached.id, verified: true }; }
  return { holder: null, holderId: null, verified: ok };
}

const MEMBER_LIST_HELP =
  "⚠️ I can't confirm whether this team is already taken because I can't read this server's member list. " +
  "Ask an admin to enable **Server Members Intent** for the bot in the Discord Developer Portal " +
  "(Bot → Privileged Gateway Intents), then restart the bot.";

// ---------------------------------------------------------------- Waitlist Coach role swap
// Got a team -> remove Waitlist Coach (and the waitlist role, as the original did).
async function onMemberGotTeam(member, teamName) {
  const notes = [];
  for (const role of [getCoachRole(member.guild), getWaitlistRole(member.guild)]) {
    if (!role || !member.roles.cache.has(role.id)) continue;
    try { await member.roles.remove(role, `TML: received team role ${teamName}`); }
    catch (err) { notes.push(`couldn't remove **${role.name}**: ${describeError(err)}`); console.error(`Remove ${role.name} from ${member.user?.tag}:`, err?.message || err); }
  }
  if (waitlist.members[member.id]) { delete waitlist.members[member.id]; saveWaitlist(); }
  return notes;
}
// Lost their team (and holds no other team) -> give Waitlist Coach back.
async function onMemberLostTeam(member, teamName) {
  if (!member || hasTeamRole(member)) return null;
  const coach = getCoachRole(member.guild);
  if (!coach) { console.warn("Waitlist Coach role not found — set WAITLIST_COACH_ROLE_ID in .env."); return "Waitlist Coach role is not configured"; }
  if (member.roles.cache.has(coach.id)) return null;
  try { await member.roles.add(coach, `TML: lost team role ${teamName}`); return null; }
  catch (err) { console.error(`Give Waitlist Coach to ${member.user?.tag}:`, err?.message || err); return `couldn't give **${coach.name}**: ${describeError(err)}`; }
}

// ---------------------------------------------------------------- team opened announcement
const recentAnnouncements = new Map(); // roleId -> timestamp (dedupe command + member-update events)
const suppressAnnouncements = new Set();
async function announceTeamOpened(guild, roleId) {
  if (suppressAnnouncements.has(guild.id)) return;
  const last = recentAnnouncements.get(roleId) || 0;
  if (Date.now() - last < 15_000) return;
  recentAnnouncements.set(roleId, Date.now());
  const role = guild.roles.cache.get(roleId);
  const name = role?.name || teamLabel(roleId);
  try {
    const channel = await guild.channels.fetch(cfg.TEAM_OPENED_CHANNEL_ID).catch(() => null);
    if (!channel || !channel.isTextBased()) { console.error(`Team-opened channel ${cfg.TEAM_OPENED_CHANNEL_ID} not accessible.`); return; }
    const waitlistRole = getWaitlistRole(guild);
    const ping = waitlistRole ? `<@&${waitlistRole.id}> ` : "";
    if (!waitlistRole) console.warn("Waitlist role not found — set WAITLIST_ROLE_ID in .env. Announcing without a ping.");
    await channel.send({
      content: `${ping}**${name}** is open, claim it while you can!!`,
      allowedMentions: { roles: waitlistRole ? [waitlistRole.id] : [] }
    });
    waitlist.announcements.push({ roleId, team: name, at: new Date().toISOString() });
    saveWaitlist();
  } catch (err) {
    console.error(`Could not announce ${name} opening:`, err?.message || err);
  }
}

// Central "team became available" path for releases (commands + role events).
async function handleTeamReleased(guild, roleId, member, reason) {
  const prev = claimedUserId(roleId);
  if (!member || prev === member.id) clearClaim(roleId, reason);
  const note = member ? await onMemberLostTeam(member, teamLabel(roleId)) : null;
  await announceTeamOpened(guild, roleId);
  teamsChanged(guild);
  return note;
}

// ---------------------------------------------------------------- sync
async function syncClaimsFromRoles(guild) {
  const ok = await ensureMembers(guild, { force: true });
  if (!ok) return { synced: 0, cleared: 0, coachRemoved: 0, coachGiven: 0, ok: false };
  let synced = 0, cleared = 0, coachRemoved = 0, coachGiven = 0;
  const coach = getCoachRole(guild);
  for (const roleId of getConfiguredTeamRoleIds()) {
    const role = guild.roles.cache.get(roleId);
    const holder = role ? role.members.first() : null;
    const recorded = claimedUserId(roleId);
    if (holder) {
      if (recorded !== holder.id) {
        if (recorded) {
          clearClaim(roleId, "sync");
          const prevMember = guild.members.cache.get(recorded);
          if (prevMember && !hasTeamRole(prevMember) && coach && !prevMember.roles.cache.has(coach.id)) { if (!(await onMemberLostTeam(prevMember, teamLabel(roleId)))) coachGiven++; }
        }
        setClaim(roleId, holder.id); synced++;
      }
    } else if (recorded) {
      clearClaim(roleId, "sync"); cleared++;
      const prevMember = guild.members.cache.get(recorded);
      if (prevMember && coach && !prevMember.roles.cache.has(coach.id)) { if (!(await onMemberLostTeam(prevMember, teamLabel(roleId)))) coachGiven++; }
      await announceTeamOpened(guild, roleId);
    }
  }
  // Every current team holder must not keep the Waitlist Coach role.
  if (coach) {
    for (const member of coach.members.values()) {
      if (hasTeamRole(member)) { const notes = await onMemberGotTeam(member, configuredTeamRolesOf(member).first().name); if (!notes.length) coachRemoved++; }
    }
  }
  teamsChanged(guild);
  return { synced, cleared, coachRemoved, coachGiven, ok: true };
}

// ---------------------------------------------------------------- claim (no screenshot verification in TML)
async function instantClaim(guild, userId, roleId) {
  return withGuildLock(guild.id, async () => {
    const role = guild.roles.cache.get(roleId);
    if (!role || !teamRoles.roles[roleId]) throw new Error("That team is no longer configured.");
    const botMember = await guild.members.fetchMe();
    if (role.position >= botMember.roles.highest.position) throw new Error("I can't assign this team because my bot role is not above it.");
    const member = await guild.members.fetch(userId);
    const held = configuredTeamRolesOf(member);
    if (held.size) throw new Error(held.first().id === roleId ? `You already have **${role.name}**.` : `You have already claimed a team (**${held.first().name}**). Ask a mod to release it if you want to switch.`);
    const { holder, verified } = await findRoleHolder(guild, role);
    if (holder) throw new Error(`Sorry — **${role.name}** has already been claimed by **${holder.user.tag}**.`);
    if (!verified) throw new Error(MEMBER_LIST_HELP);
    await member.roles.add(role, `TML team claim by ${member.user.tag}`);
    setClaim(roleId, userId);
    const notes = await onMemberGotTeam(member, role.name);
    teamsChanged(guild);
    return notes.length ? `\n⚠️ ${notes.join("; ")}` : "";
  });
}

async function postTeamPanels(guild, channel) {
  let posted = 0;
  for (const conference of ["AFC", "NFC"]) {
    const entries = Object.entries(teamRoles.roles).filter(([, d]) => d.category === conference).sort((a, b) => a[1].label.localeCompare(b[1].label));
    if (!entries.length) continue;
    const rows = [];
    for (let i = 0; i < entries.length; i += 5) {
      const row = new ActionRowBuilder();
      for (const [roleId, data] of entries.slice(i, i + 5)) row.addComponents(teamButton(guild, roleId, data));
      rows.push(row);
    }
    const embed = new EmbedBuilder().setTitle(`${conference} Teams`).setDescription("Click a team to claim it.\n\n**Each team can only be claimed by ONE member.**\n**Each member can only claim ONE team.**");
    await channel.send({ embeds: [embed], components: rows });
    posted++;
  }
  return posted;
}

// ---------------------------------------------------------------- open teams (used by openTeams.js)
async function getOpenTeams(guild) {
  await ensureMembers(guild);
  const open = [];
  for (const team of TEAMS) {
    const roleId = getConfiguredTeamRoleIds().find(id => teamRoles.roles[id]?.label === team.name);
    const role = roleId ? guild.roles.cache.get(roleId) : null;
    if (!role) continue; // not set up yet
    const holder = role.members.first();
    if (!holder) { if (claimedUserId(roleId)) clearClaim(roleId, "stale"); open.push({ team, role }); }
  }
  return { open, configured: getConfiguredTeamRoleIds().length };
}

// ---------------------------------------------------------------- Discord events
async function onGuildMemberUpdate(oldMember, newMember) {
  for (const roleId of getConfiguredTeamRoleIds()) {
    const had = oldMember.partial ? claimedUserId(roleId) === newMember.id : oldMember.roles.cache.has(roleId);
    const has = newMember.roles.cache.has(roleId);
    if (!had && has) {
      setClaim(roleId, newMember.id);
      await onMemberGotTeam(newMember, teamLabel(roleId));
      teamsChanged(newMember.guild);
    } else if (had && !has) {
      await handleTeamReleased(newMember.guild, roleId, newMember, "role removed");
    }
  }
}
async function onGuildMemberRemove(member) {
  for (const roleId of getConfiguredTeamRoleIds()) {
    const wasHolder = member.roles?.cache?.has(roleId) || claimedUserId(roleId) === member.id;
    if (wasHolder) {
      if (claimedUserId(roleId) === member.id) clearClaim(roleId, "left server");
      await announceTeamOpened(member.guild, roleId);
      teamsChanged(member.guild);
    }
  }
  if (waitlist.members[member.id]) { delete waitlist.members[member.id]; saveWaitlist(); }
}
async function onReady(guild) {
  const result = await syncClaimsFromRoles(guild);
  if (!result.ok) console.error(MEMBER_LIST_HELP);
  else console.log(`Startup claim sync: ${result.synced} linked, ${result.cleared} cleared, coach removed ${result.coachRemoved}, coach given ${result.coachGiven}.`);
}

// ---------------------------------------------------------------- slash commands
const COMMAND_NAMES = ["sync-teams", "my-team", "release-member", "release-team", "setup-nfl-teams", "waitlist-button"];

async function handleCommand(interaction) {
  const name = interaction.commandName;
  const guild = interaction.guild;

  if (name === "my-team") {
    const member = await guild.members.fetch(interaction.user.id);
    const team = configuredTeamRolesOf(member).first();
    return interaction.reply({ content: team ? `You have claimed **${team.name}**.` : "You haven't claimed a team yet.", ephemeral: true });
  }

  if (name === "waitlist-button") {
    if (!isAdmin(interaction)) return interaction.reply({ content: "❌ Only administrators can use **/waitlist-button**.", ephemeral: true });
    if (!getWaitlistRole(guild)) return interaction.reply({ content: `❌ I couldn't find the waitlist role. Set **WAITLIST_ROLE_ID** in .env (or create a role named **${cfg.WAITLIST_ROLE_NAME}**).`, ephemeral: true });
    const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId("waitlist:join").setLabel("join the waitlist!").setStyle(ButtonStyle.Primary));
    await interaction.channel.send({ content: "Need a team? Click the button below to join the waitlist!", components: [row] });
    return interaction.reply({ content: "✅ Waitlist button posted.", ephemeral: true });
  }

  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageRoles)) return interaction.reply({ content: "You need **Manage Roles** to use this command.", ephemeral: true });

  if (name === "setup-nfl-teams") {
    await interaction.deferReply({ ephemeral: true });
    const createMissing = interaction.options.getBoolean("create-missing") ?? true;
    const botMember = await guild.members.fetchMe();
    await guild.roles.fetch();
    const created = [], linked = [], problems = [];
    for (const team of TEAMS) {
      let role = guild.roles.cache.find(r => r.name.toLowerCase() === team.name.toLowerCase());
      if (!role) {
        if (!createMissing) { problems.push(`${team.name} — role not found`); continue; }
        try { role = await guild.roles.create({ name: team.name, mentionable: true, reason: `TML NFL team role created by ${interaction.user.tag}` }); created.push(team.name); }
        catch (err) { problems.push(`${team.name} — could not create role (${describeError(err)})`); continue; }
      } else linked.push(team.name);
      if (role.managed || role.position >= botMember.roles.highest.position) problems.push(`${team.name} — move my bot role above it in Server Settings → Roles`);
      // Drop any older entry for the same team so each team has one role.
      for (const [id, d] of Object.entries(teamRoles.roles)) if (d.label === team.name && id !== role.id) delete teamRoles.roles[id];
      teamRoles.roles[role.id] = { label: team.name, emoji: team.emoji, roleName: team.name, category: team.conference };
    }
    for (const roleId of Object.keys(teamRoles.roles)) if (!guild.roles.cache.has(roleId)) delete teamRoles.roles[roleId];
    saveRoles();
    const sync = await syncClaimsFromRoles(guild);
    let msg = `Set up **${Object.keys(teamRoles.roles).length}** TML NFL team roles (AFC + NFC).\n• Created: **${created.length}**\n• Linked to existing roles: **${linked.length}**\n• Current holders synced: **${sync.ok ? "yes" : "no — member list unavailable"}**`;
    if (problems.length) msg += `\n\n⚠️ Needs attention:\n- ${problems.slice(0, 15).join("\n- ")}`;
    if (interaction.options.getBoolean("post-panels") ?? true) {
      try { const n = await postTeamPanels(guild, interaction.channel); msg += `\n\nPosted **${n}** claim panel${n === 1 ? "" : "s"} in this channel.`; }
      catch (err) { msg += `\n\n⚠️ Couldn't post claim panels here: ${describeError(err)}`; }
    }
    return interaction.editReply({ content: msg.slice(0, 1990) });
  }

  if (name === "sync-teams") {
    await interaction.deferReply({ ephemeral: true });
    const r = await syncClaimsFromRoles(guild);
    if (!r.ok) return interaction.editReply({ content: MEMBER_LIST_HELP });
    const takenCount = Object.keys(teamClaims.claims).length;
    return interaction.editReply({ content: `✅ Synced with the server. **${takenCount}** team${takenCount === 1 ? " is" : "s are"} currently taken (${r.synced} newly linked, ${r.cleared} stale claim${r.cleared === 1 ? "" : "s"} cleared).\n• Waitlist Coach removed from team holders: **${r.coachRemoved}**\n• Waitlist Coach given back to former holders: **${r.coachGiven}**${getCoachRole(guild) ? "" : "\n⚠️ Waitlist Coach role not found — set WAITLIST_COACH_ROLE_ID."}` });
  }

  if (name === "release-team") {
    const role = interaction.options.getRole("role");
    if (!teamRoles.roles[role.id]) return interaction.reply({ content: "That role isn't configured as a TML NFL team role.", ephemeral: true });
    await interaction.deferReply({ ephemeral: true });
    return withGuildLock(interaction.guildId, async () => {
      const { holder } = await findRoleHolder(guild, role);
      if (!holder) { clearClaim(role.id, "already open"); teamsChanged(guild); return interaction.editReply({ content: `**${role.name}** is already available.` }); }
      await holder.roles.remove(role, `Released by ${interaction.user.tag}`);
      clearPending(interaction.guildId, holder.id);
      const fresh = await guild.members.fetch(holder.id).catch(() => holder);
      const note = await handleTeamReleased(guild, role.id, fresh, `released by ${interaction.user.tag}`);
      return interaction.editReply({ content: `Released **${role.name}** from **${holder.user.tag}**. It can be claimed again.${note ? `\n⚠️ ${note}` : ""}` });
    });
  }

  if (name === "release-member") {
    const user = interaction.options.getUser("member");
    await interaction.deferReply({ ephemeral: true });
    return withGuildLock(interaction.guildId, async () => {
      const member = await guild.members.fetch(user.id);
      const held = configuredTeamRolesOf(member);
      if (!held.size) return interaction.editReply({ content: `**${user.tag}** hasn't claimed a team.` });
      await member.roles.remove([...held.keys()], `Team reset by ${interaction.user.tag}`);
      clearPending(interaction.guildId, user.id);
      const fresh = await guild.members.fetch(user.id).catch(() => member);
      let note = null;
      for (const teamRole of held.values()) note = (await handleTeamReleased(guild, teamRole.id, fresh, `released by ${interaction.user.tag}`)) || note;
      return interaction.editReply({ content: `Removed **${held.map(r => r.name).join(", ")}** from **${user.tag}**. They can claim again.${note ? `\n⚠️ ${note}` : ""}` });
    });
  }

  return false;
}

// ---------------------------------------------------------------- buttons / modals
async function handleComponent(interaction) {
  const guild = interaction.guild;
  if (interaction.isButton() && interaction.customId === "waitlist:join") {
    const waitlistRole = getWaitlistRole(guild);
    if (!waitlistRole) return interaction.reply({ content: "❌ The waitlist role could not be found. Ask an admin to set WAITLIST_ROLE_ID.", ephemeral: true });
    const member = await guild.members.fetch(interaction.user.id);
    if (hasTeamRole(member)) return interaction.reply({ content: `❌ You already have the **${configuredTeamRolesOf(member).first().name}** team role, so you can't join the waitlist.`, ephemeral: true });
    if (member.roles.cache.has(waitlistRole.id)) return interaction.reply({ content: "ℹ️ You're already on the waitlist.", ephemeral: true });
    try {
      await member.roles.add(waitlistRole, "Joined waitlist from waitlist button");
      waitlist.members[member.id] = { joinedAt: new Date().toISOString(), via: "button" }; saveWaitlist();
      return interaction.reply({ content: "✅ You're on the **waitlist**! You'll be notified when a team opens.", ephemeral: true });
    } catch (err) {
      registerRateLimit(err);
      return interaction.reply({ content: `❌ I couldn't add the waitlist role: ${describeError(err)}`, ephemeral: true });
    }
  }

  if (interaction.isButton() && interaction.customId.startsWith("claim:")) {
    const roleId = interaction.customId.slice("claim:".length), data = teamRoles.roles[roleId], role = guild.roles.cache.get(roleId);
    if (!data) return interaction.reply({ content: "This team button is no longer configured.", ephemeral: true });
    if (!role) return interaction.reply({ content: "That team role no longer exists.", ephemeral: true });
    if (rateLimitSecondsLeft() > 0) return interaction.reply({ content: rateLimitNotice("Discord is rate-limiting the bot right now."), ephemeral: true });
    await interaction.deferReply({ ephemeral: true });
    try {
      const note = await instantClaim(guild, interaction.user.id, roleId);
      return interaction.editReply({ content: `✅ You claimed **${role.name}**!${note}` });
    } catch (err) {
      registerRateLimit(err);
      return interaction.editReply({ content: `❌ ${describeError(err)}` });
    }
  }
  return false;
}
const ownsComponent = id => id === "waitlist:join" || id.startsWith("claim:");

// Discord user who currently owns the team with this short name ("Bills"), or null. Used by Auto POTW.
function ownerOfTeamLabel(label) {
  const wanted = String(label || "").trim().toLowerCase();
  const roleId = Object.keys(teamRoles.roles).find(id => String(teamRoles.roles[id]?.label).toLowerCase() === wanted);
  return roleId ? (teamClaims.claims[roleId] || null) : null;
}

module.exports = {
  COMMAND_NAMES, handleCommand, handleComponent, ownsComponent,
  onGuildMemberUpdate, onGuildMemberRemove, onReady,
  getOpenTeams, ownerOfTeamLabel, resolveGuildEmoji, setTeamsChangedHook, teamRoles, teamClaims,
  configuredTeamRolesOf, ensureMembers,
  // exported for tests
  _internal: { onMemberGotTeam, onMemberLostTeam, handleTeamReleased, clearClaim, setClaim, recentAnnouncements }
};
