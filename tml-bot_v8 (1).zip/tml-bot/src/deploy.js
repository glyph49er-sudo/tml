const { REST, Routes } = require("discord.js");
const cfg = require("./config");
const { commandJson } = require("./commands");

async function deployCommands() {
  if (!cfg.TOKEN || !cfg.CLIENT_ID || !cfg.GUILD_ID) throw new Error("DISCORD_TOKEN, CLIENT_ID and GUILD_ID must be set in .env");
  const rest = new REST({ version: "10" }).setToken(cfg.TOKEN);
  const body = commandJson();
  await rest.put(Routes.applicationGuildCommands(cfg.CLIENT_ID, cfg.GUILD_ID), { body });
  return body.length;
}
module.exports = { deployCommands };
