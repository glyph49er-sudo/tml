// Keeps one "Open Teams" status message at the bottom of the open-teams channel.
// - Refreshed whenever anyone (not this bot) posts in that channel.
// - Refreshed whenever a team is claimed or released.
// - Refreshes are debounced and serialized; the bot ignores its own messages,
//   so posting the status never triggers another refresh (no loop).
const { EmbedBuilder } = require("discord.js");
const cfg = require("./config");
const { readJson, writeJson } = require("./store");
const teamClaimer = require("./teamClaimer");

const state = readJson("openTeams", { channelId: null, messageId: null, updatedAt: null });
let timer = null;
let running = Promise.resolve();
let latestGuild = null;

function buildEmbed(guild, open, configured) {
  const embed = new EmbedBuilder().setTitle("🏈 Open TML Teams").setTimestamp(new Date());
  if (!configured) return embed.setDescription("Teams haven't been set up yet. An admin needs to run **/setup-nfl-teams**.");
  if (!open.length) return embed.setDescription("**Every team is currently taken.**\nJoin the waitlist to be pinged when one opens up.");
  const by = conf => open.filter(x => x.team.conference === conf)
    .map(x => `${teamClaimer.resolveGuildEmoji(guild, x.team.emoji)} ${x.team.name}`).join("\n") || "None";
  return embed
    .setDescription(`**${open.length}** team${open.length === 1 ? " is" : "s are"} open right now.`)
    .addFields({ name: "AFC", value: by("AFC").slice(0, 1024), inline: true }, { name: "NFC", value: by("NFC").slice(0, 1024), inline: true });
}

async function refreshNow(guild) {
  const channel = await guild.channels.fetch(cfg.OPEN_TEAMS_CHANNEL_ID).catch(() => null);
  if (!channel || !channel.isTextBased()) { console.error(`Open-teams channel ${cfg.OPEN_TEAMS_CHANNEL_ID} not accessible (View Channel / Send Messages needed).`); return; }
  const { open, configured } = await teamClaimer.getOpenTeams(guild);
  const payload = { content: "", embeds: [buildEmbed(guild, open, configured)] };
  const me = guild.client.user.id;

  // If our status message is already the newest message, just edit it.
  const latest = await channel.messages.fetch({ limit: 1 }).then(c => c.first()).catch(() => null);
  if (state.messageId && state.channelId === channel.id && latest?.id === state.messageId && latest.author.id === me) {
    try { await latest.edit(payload); state.updatedAt = new Date().toISOString(); writeJson("openTeams", state); return; }
    catch (err) { console.error("Edit open-teams message failed, reposting:", err?.message || err); }
  }
  // Otherwise delete the old one and post a fresh one at the bottom.
  if (state.messageId && state.channelId) {
    const old = await channel.messages.fetch(state.messageId).catch(() => null);
    if (old) await old.delete().catch(err => console.error("Delete old open-teams message:", err?.message || err));
  }
  const sent = await channel.send(payload);
  state.channelId = channel.id; state.messageId = sent.id; state.updatedAt = new Date().toISOString();
  writeJson("openTeams", state);
}

// Debounced, serialized refresh request.
function requestRefresh(guild, delayMs = 2500) {
  if (!guild) return;
  latestGuild = guild;
  clearTimeout(timer);
  timer = setTimeout(() => {
    running = running.then(() => refreshNow(latestGuild)).catch(err => console.error("Open-teams refresh failed:", err?.message || err));
  }, delayMs);
}

function onMessageCreate(message) {
  if (!message.guild || message.channelId !== cfg.OPEN_TEAMS_CHANNEL_ID) return;
  if (message.author.id === message.client.user.id) return; // never react to our own posts
  requestRefresh(message.guild);
}

module.exports = { requestRefresh, onMessageCreate, refreshNow, _state: state };
