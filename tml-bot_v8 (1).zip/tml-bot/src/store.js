// Safe JSON persistence: missing files are created, corrupted files are backed
// up (never silently overwritten) and replaced with defaults, writes are atomic.
const fs = require("node:fs");
const path = require("node:path");

const DATA_DIR = process.env.TML_DATA_DIR || path.join(__dirname, "..", "data");
fs.mkdirSync(DATA_DIR, { recursive: true });

const FILES = {
  settings: "settings.json",
  teamRoles: "team-roles.json",
  teamClaims: "team-claims.json",
  waitlist: "waitlist.json",
  openTeams: "open-teams-message.json",
  potw: "player-of-the-week.json",
  gotw: "game-of-the-week.json",
  mysteryBox: "mystery-box.json",
  prospects: "prospects.json",
  prospectSheets: "prospect-sheets.json",
  scouting: "scouting.json"
};

function filePath(name) { return path.join(DATA_DIR, FILES[name] || name); }

function isPlainObject(v) { return v && typeof v === "object" && !Array.isArray(v); }

function writeJson(name, value) {
  const file = filePath(name);
  const tmp = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(value, null, 2));
  fs.renameSync(tmp, file);
}

// `defaults` is an object; every top-level key of defaults is guaranteed to
// exist with the same type in the returned value.
function readJson(name, defaults) {
  const file = filePath(name);
  const fresh = () => JSON.parse(JSON.stringify(defaults));
  if (!fs.existsSync(file)) {
    const v = fresh();
    writeJson(name, v);
    return v;
  }
  let parsed;
  try {
    parsed = JSON.parse(fs.readFileSync(file, "utf8"));
    if (!isPlainObject(parsed)) throw new Error("top-level value is not an object");
  } catch (err) {
    const backup = `${file}.corrupt-${Date.now()}`;
    try { fs.copyFileSync(file, backup); } catch {}
    console.error(`[store] ${path.basename(file)} was unreadable (${err.message}). Backed up to ${path.basename(backup)} and reset.`);
    const v = fresh();
    writeJson(name, v);
    return v;
  }
  for (const [key, def] of Object.entries(defaults)) {
    const cur = parsed[key];
    const ok = Array.isArray(def) ? Array.isArray(cur) : isPlainObject(def) ? isPlainObject(cur) : cur !== undefined && (def === null || typeof cur === typeof def || cur === null);
    if (!ok) parsed[key] = JSON.parse(JSON.stringify(def));
  }
  return parsed;
}

module.exports = { readJson, writeJson, DATA_DIR, FILES };
