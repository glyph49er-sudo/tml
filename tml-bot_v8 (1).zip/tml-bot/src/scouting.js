// One scout per person per fixed two-day Los Angeles window; all reveals persist.
const { readJson, writeJson } = require("./store");
const { isAdmin, chunkLines } = require("./util");
const stats = require("./prospectStats");
const store = readJson("scouting", { users: {}, uses: {} });
const save = () => writeJson("scouting", store);
const COMMAND_NAMES = ["scout-player", "scout-sheet", "reset-scout-sheets"];
const DAY_MS=86400000,ANCHOR_DAY=Date.UTC(2026,0,1)/DAY_MS;
function partsAt(date){
  const parts=new Intl.DateTimeFormat("en-US",{timeZone:"America/Los_Angeles",year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit",hourCycle:"h23"}).formatToParts(date);
  return Object.fromEntries(parts.filter(p=>p.type!=="literal").map(p=>[p.type,Number(p.value)]));
}
function localDayNumber(date){const p=partsAt(date);return Date.UTC(p.year,p.month-1,p.day)/DAY_MS;}
function losAngelesNoonUtc(dayNumber){
  const d=new Date(dayNumber*DAY_MS),year=d.getUTCFullYear(),month=d.getUTCMonth(),day=d.getUTCDate();let guess=Date.UTC(year,month,day,12);
  for(let n=0;n<2;n++){const p=partsAt(new Date(guess));const represented=Date.UTC(p.year,p.month-1,p.day,p.hour,p.minute,p.second);guess+=Date.UTC(year,month,day,12)-represented;}
  return new Date(guess);
}
function scoutWindow(now=new Date()){
  const day=localDayNumber(now),periods=Math.floor((day-ANCHOR_DAY)/2);let startDay=ANCHOR_DAY+periods*2;
  let start=losAngelesNoonUtc(startDay),end=losAngelesNoonUtc(startDay+2);
  if(now<start){startDay-=2;start=losAngelesNoonUtc(startDay);end=losAngelesNoonUtc(startDay+2);}
  return{key:start.toISOString(),start,end};
}
function userRecord(userId){
  if(!store.users[userId])store.users[userId]={players:{},history:[]};
  if(!store.users[userId].players)store.users[userId].players={};
  if(!Array.isArray(store.users[userId].history))store.users[userId].history=[];
  return store.users[userId];
}
function knownFor(user,sheetId){
  if(!user.players[sheetId])user.players[sheetId]={stats:{},developmentKnown:false,fullSheet:false,scouts:0};
  return user.players[sheetId];
}
function scout(userId,sheet,now=new Date(),rng=Math.random){
  const window=scoutWindow(now),use=store.uses[userId];
  if(use?.window===window.key&&use.count>=1)return{limited:true,resetAt:window.end};
  const fullSheet=rng()<.01,developmentKnown=rng()<.20;
  const pool=stats.POSITIONS[sheet.position]?.core||stats.POSITIONS.ATH.core,code=pool[Math.floor(rng()*pool.length)];
  const user=userRecord(userId),known=knownFor(user,sheet.id),revealed=fullSheet?stats.ATTRIBUTES.map(a=>a.code):[code];
  for(const c of revealed)known.stats[c]=sheet.ratings[c];
  known.developmentKnown||=developmentKnown;known.fullSheet||=fullSheet;known.scouts++;
  store.uses[userId]={window:window.key,count:1,lastAt:now.toISOString()};
  user.history.push({sheetId:sheet.id,playerName:sheet.name,at:now.toISOString(),code,rating:sheet.ratings[code],fullSheet,development:developmentKnown?sheet.development:null});
  save();return{limited:false,sheet,code,fullSheet,developmentKnown,resetAt:window.end,known};
}
function sheetLinesForUser(userId){
  const user=store.users[userId];if(!user||!Object.keys(user.players||{}).length)return[];
  const lines=["**YOUR SCOUT SHEET**","Only ratings and development traits you have revealed are shown."];
  const entries=Object.entries(user.players).sort((a,b)=>(stats.getSheet(a[0])?.name||"").localeCompare(stats.getSheet(b[0])?.name||""));
  for(const [sheetId,known] of entries){
    const sheet=stats.getSheet(sheetId);if(!sheet)continue;
    lines.push("",`**${sheet.name} — ${sheet.position}**`,`Scouts used on this player: ${known.scouts}`);
    if(known.developmentKnown)lines.push(`Development Trait: **${sheet.development}**`);
    const codes=Object.keys(known.stats);if(!codes.length)lines.push("No attribute ratings revealed yet.");
    else for(const code of stats.ATTRIBUTES.map(a=>a.code).filter(c=>codes.includes(c)))lines.push(`${stats.BY_CODE[code].name} (${code}): **${known.stats[code]}**`);
  }
  return lines;
}
async function replyLines(i,lines){
  const chunks=chunkLines("",lines,1900);
  if(!chunks.length)return i.reply({content:"Your scout sheet is empty. Use `/scout-player` first.",ephemeral:true});
  await i.reply({content:chunks[0],ephemeral:true,allowedMentions:{parse:[]}});
  for(const chunk of chunks.slice(1))await i.followUp({content:chunk,ephemeral:true,allowedMentions:{parse:[]}});
}
async function handleCommand(i){
  if(i.commandName==="reset-scout-sheets"){
    if(!isAdmin(i))return i.reply({content:"You must be an administrator to use this command.",ephemeral:true});
    const count=Object.keys(store.users).length;store.users={};store.uses={};save();
    return i.reply({content:`✅ Wiped scout sheets and scout-use limits for **${count}** user${count===1?"":"s"}. Generated prospect sheets were kept.`,ephemeral:true});
  }
  if(i.commandName==="scout-sheet")return replyLines(i,sheetLinesForUser(i.user.id));
  if(i.commandName!=="scout-player")return false;
  const name=i.options.getString("player",true).trim(),matches=stats.findProspects(name);
  if(!matches.length)return i.reply({content:`I couldn't find a generated prospect named **${name.slice(0,80)}**. Check the spelling or create the prospect first.`,ephemeral:true,allowedMentions:{parse:[]}});
  if(matches.length>1){const list=matches.slice(0,8).map(s=>`• ${s.name} — ${s.position}, ${s.college}`).join("\n");return i.reply({content:`That name matches more than one prospect. Use the full name:\n${list}`,ephemeral:true});}
  const sheet=matches[0],window=scoutWindow(),existingUse=store.uses[i.user.id];
  if(existingUse?.window===window.key&&existingUse.count>=1)return i.reply({content:`⏳ You already used this scouting window's scout. You can scout again <t:${Math.floor(window.end.getTime()/1000)}:R> (<t:${Math.floor(window.end.getTime()/1000)}:F>).`,ephemeral:true});
  const result=scout(i.user.id,sheet);
  if(result.limited)return i.reply({content:`⏳ You can scout again <t:${Math.floor(result.resetAt.getTime()/1000)}:R>.`,ephemeral:true});
  const lines=[result.fullSheet?`🕵️ **FULL SCOUT REVEAL — ${sheet.name}**`:`🕵️ **Scout Report — ${sheet.name} (${sheet.position})**`,
    result.fullSheet?"**1% bonus: every attribute revealed!**":`${stats.BY_CODE[result.code].name} (${result.code}): **${sheet.ratings[result.code]}**`,
    result.developmentKnown?`**20% bonus: Development Trait — ${sheet.development}**`:null,
    `Saved to \`/scout-sheet\`. Next scout: <t:${Math.floor(result.resetAt.getTime()/1000)}:R>.`].filter(Boolean);
  if(result.fullSheet)lines.push(...stats.ratingLines(sheet));return replyLines(i,lines);
}
module.exports={COMMAND_NAMES,handleCommand,_internal:{scoutWindow,scout,sheetLinesForUser,losAngelesNoonUtc,store}};
