require("dotenv").config({ quiet: true });

function env(name, fallback = "") {
  const v = process.env[name];
  return v == null || String(v).trim() === "" ? fallback : String(v).trim();
}

// IDs the TML owner provided are used as defaults. IDs that were NOT provided
// (guild, roles) have no default and must be configured.
module.exports = {
  TOKEN: env("DISCORD_TOKEN"),
  CLIENT_ID: env("CLIENT_ID"),
  GUILD_ID: env("GUILD_ID"),

  TEAM_OPENED_CHANNEL_ID: env("TEAM_OPENED_CHANNEL_ID", "1481828808087699516"),
  OPEN_TEAMS_CHANNEL_ID: env("OPEN_TEAMS_CHANNEL_ID", "1563478213630632006"),
  PROSPECT_CHANNEL_ID: env("PROSPECT_CHANNEL_ID", "1561708316000784384"),
  PROSPECT_STATS_CHANNEL_ID: env("PROSPECT_STATS_CHANNEL_ID", "1570602743834611924"),
  FRANCHISE_HUB_CHANNEL_ID: env("FRANCHISE_HUB_CHANNEL_ID", "1438019992347082823"),
  // Where Auto Player of the Week posts.
  POTW_CHANNEL_ID: env("POTW_CHANNEL_ID", "1550304580695367710"),

  WAITLIST_ROLE_ID: env("WAITLIST_ROLE_ID"),
  WAITLIST_ROLE_NAME: env("WAITLIST_ROLE_NAME", "waitlist"),
  WAITLIST_COACH_ROLE_ID: env("WAITLIST_COACH_ROLE_ID"),
  WAITLIST_COACH_ROLE_NAME: env("WAITLIST_COACH_ROLE_NAME", "Waitlist Coach"),


  TIMEZONE: "America/Los_Angeles"
};
