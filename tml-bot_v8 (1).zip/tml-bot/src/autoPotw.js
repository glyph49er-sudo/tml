// Auto Player of the Week. Ported from the FDL bot's franchise.js: once Madden has finished a week and
// published its weekly awards (AFC/NFC Offense + AFC/NFC Defense), TML posts a NEW Player of the Week
// message by itself. Winners are the Discord owners of those players' teams. The post uses TML's normal
// Player of the Week layout and Claim Award button (see awards.js).
// Set AUTO_POTW=false to turn the automatic posting off; /auto-potw always works for admins.
const { PermissionFlagsBits } = require("discord.js");
const fs = require("node:fs");
const path = require("node:path");
const cfg = require("./config");
const EA = require("./eaConnector");
const D = require("./franchiseData");
const eaLink = require("./eaLink");
const awards = require("./awards");
const teamClaimer = require("./teamClaimer");
const { DATA_DIR } = require("./store");
const { isAdmin, describeError } = require("./util");
const { TEAMS } = require("../teams");

class UserError extends Error {}
const CACHE_MS = 5 * 60 * 1000, ROSTER_CACHE_MS = 15 * 60 * 1000;
const STATE_FILE = path.join(DATA_DIR, "auto-potw.json");

function readState() {
  try { const v = JSON.parse(fs.readFileSync(STATE_FILE, "utf8")); if (v && typeof v.posted === "object") return v; } catch { /* first run */ }
  return { posted: {} };
}
function writeState(state) {
  const tmp = `${STATE_FILE}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(state, null, 2));
  fs.renameSync(tmp, STATE_FILE);
}

// ------------------------------------------------------------ EA access (cached)
const cache = new Map();
function cached(key, ttl, fn) {
  const hit = cache.get(key);
  if (hit && hit.value !== undefined && Date.now() - hit.at < ttl) return Promise.resolve(hit.value);
  if (hit && hit.promise) return hit.promise;
  const promise = fn().then(value => { cache.set(key, { at: Date.now(), value }); return value; }).catch(err => { cache.delete(key); throw err; });
  cache.set(key, { promise });
  return promise;
}
const peek = key => { const hit = cache.get(key); return hit && hit.value !== undefined ? hit.value : null; };

async function withEA(fn) {
  const conn = eaLink.getConnection();
  if (!conn?.refreshToken || !conn?.leagueId) throw new UserError("TML is not connected to the Madden franchise yet. An admin needs to run `/ea-connect`.");
  const before = conn.refreshToken;
  try { return await fn(conn); }
  finally { if (conn.refreshToken !== before) { try { eaLink.saveConnection(); } catch (e) { console.error("[auto-potw] could not save refreshed EA token:", e.message); } } }
}
const getTeams = () => cached("teams", CACHE_MS, async () => D.normalizeTeams(await withEA(c => EA.getTeams(c))));
async function getStandings() {
  const teams = await getTeams();
  return D.normalizeStandings(await cached("standings", CACHE_MS, () => withEA(c => EA.getStandings(c))), teams);
}
const getHub = () => cached("hub", CACHE_MS, () => withEA(c => EA.getLeagueInfo(c)));
let lastWeek = null;
function getCurrent() {
  return cached("current", 30 * 1000, async () => {
    const hub = await withEA(c => EA.getLeagueInfo(c)).catch(() => peek("hub") || {});
    cache.set("hub", { at: Date.now(), value: hub });
    const cur = D.currentWeekFromHub(hub);
    const teams = await getTeams();
    const week = await D.advanceToOpenWeek(cur.week, async w => {
      const raw = await withEA(c => EA.getSchedule(c, w - 1)).catch(() => null);
      if (!raw || !raw.length) return null;
      cache.set(`schedule:${w}`, { at: Date.now(), value: raw });
      return D.normalizeGames(raw, teams).every(g => g.final);
    });
    if (lastWeek !== null && week !== lastWeek) for (const k of [...cache.keys()]) if (/^(schedule|stats|standings|roster|allPlayers|freeAgents)/.test(k)) cache.delete(k);
    lastWeek = week;
    return { ...cur, week };
  });
}
async function getGames(week) {
  const teams = await getTeams();
  return D.normalizeGames(await cached(`schedule:${week}`, CACHE_MS, () => withEA(c => EA.getSchedule(c, week - 1))), teams);
}
const getStats = week => cached(`stats:${week}`, CACHE_MS, () => withEA(c => EA.getWeeklyStats(c, week - 1)));
async function getRoster(team) {
  const byId = D.teamsById(await getTeams());
  const raw = await cached(`roster:${team.id}`, ROSTER_CACHE_MS, () => withEA(c => EA.getTeamRoster(c, team.id, team.index)));
  return raw.map(p => D.normalizePlayer({ ...p, teamId: p.teamId ?? team.id }, byId));
}
async function getFreeAgents() {
  const byId = D.teamsById(await getTeams());
  return (await cached("freeAgents", ROSTER_CACHE_MS, () => withEA(c => EA.getFreeAgents(c)))).map(p => D.normalizePlayer({ ...p, teamId: 0 }, byId));
}
const getAllPlayers = () => cached("allPlayers", ROSTER_CACHE_MS, async () => {
  const all = [];
  for (const team of await getTeams()) all.push(...await getRoster(team));
  all.push(...await getFreeAgents().catch(() => []));
  return all;
});

// ------------------------------------------------------------ Players of the Week
// Madden's own weekly awards when the EA export carries them; otherwise the best AFC/NFC offense and
// defense performer from that week's stats. Each line carries the stat line.
async function buildPotw(week) {
  const [hub, players, stats, standings, teams] = await Promise.all([getHub().catch(() => null), getAllPlayers(), getStats(week).catch(() => ({})), getStandings(), getTeams()]);
  const byId = D.teamsById(teams);
  const confOfId = Object.fromEntries(standings.map(r => [r.teamId, (r.division || "").slice(0, 3)]));
  const perfs = D.playerPerformances(stats, byId);
  let list = D.extractWeeklyAwards({ players, hub, week }), source = "madden";
  if (list.length) {
    list = list.map(a => {
      const perf = perfs.find(p => p.name === a.name && (!a.teamId || p.teamId === a.teamId)) || perfs.find(p => p.name === a.name);
      const conf = confOfId[a.teamId || perf?.teamId];
      const side = a.category === "Offensive" ? "Offense" : a.category === "Defensive" ? "Defense" : null;
      return { ...a, category: conf && side ? `${conf} ${side}` : a.category, statLine: perf?.statLine || "" };
    });
  } else { list = D.conferenceAwards(perfs, id => confOfId[id] || null); source = "stats"; }
  if (!list.length) throw new UserError(`I don't have week ${week}'s stats or awards yet (they appear after the week is simmed).`);
  for (const a of list) if (!a.pos) a.pos = players.find(p => p.name === a.name && (!a.teamId || p.teamId === a.teamId))?.pos || "";
  const picked = list.map(a => ({
    userId: ownerOfTeam(a.team), name: a.name, team: a.team,
    line: `**${a.category}:** **${a.name}** (${a.pos ? `${a.pos}, ` : ""}${a.team})${a.statLine ? ` — ${a.statLine}` : ""}`
  }));
  picked.sig = `${source}|` + list.map(a => `${a.category}:${a.name}`).join("|");
  picked.source = source;
  return picked;
}

// EA team names ("Bills", "Buffalo Bills", "BUF") -> the Discord user who claimed that TML team.
function ownerOfTeam(name) {
  const w = String(name || "").trim().toLowerCase();
  if (!w) return null;
  const team = TEAMS.find(t => [t.name, t.fullName, t.abbr].some(x => String(x).toLowerCase() === w)) || TEAMS.find(t => w.endsWith(` ${t.name.toLowerCase()}`));
  return teamClaimer.ownerOfTeamLabel(team ? team.name : name);
}

async function postPotw(client, week, { force = false, channelId = cfg.POTW_CHANNEL_ID, fallbackChannel = null } = {}) {
  const { season } = await getCurrent();
  const key = `${season ?? "x"}-${week}`;
  const state = readState();
  if (state.posted[key] && !force) throw new UserError(`Player of the Week for week ${week} was already posted. Use \`force: true\` to post it again.`);
  const picked = await buildPotw(week);
  // Some EA fields stay set until the next awards come out: don't re-post last week's winners.
  if (!force && state.lastSig === picked.sig) throw new UserError(`Madden still shows last week's awards for week ${week}; waiting for the new ones.`);
  const channel = channelId ? await client.channels.fetch(channelId).catch(() => null) : fallbackChannel;
  if (!channel?.isTextBased()) throw new UserError(channelId ? `I can't access the Player of the Week channel (${channelId}).` : "No Player of the Week channel is set. Set POTW_CHANNEL_ID in .env or run /auto-potw in the channel you want.");
  if (!picked.some(p => p.userId)) throw new UserError(`None of week ${week}'s award winners are on a claimed TML team, so there is nobody to post for.`);
  const sent = await awards.postAutoPotw(channel, week, picked.map(p => ({ userId: p.userId, line: p.line })));
  state.posted[key] = { messageId: sent.id, channelId: channel.id, at: Date.now() };
  state.lastSig = picked.sig;
  writeState(state);
  return { sent, picked };
}

// After a sim Madden publishes its weekly awards; the first time they show up for a finished week a NEW
// Player of the Week post is made (an old post is never edited).
const awardsWaiting = new Set();
async function autoPotwTick(client) {
  const result = { posted: false };
  try {
    if (!eaLink.isConnected() || !cfg.POTW_CHANNEL_ID) return result;
    const { week: current, season } = await getCurrent();
    if (!current) return result;
    const state = readState();
    for (const week of [current - 1, current].filter(w => w >= 1)) {
      if (state.posted[`${season ?? "x"}-${week}`]) continue;
      const games = await getGames(week);
      if (!games.length || !games.every(g => g.final)) continue;
      try { await postPotw(client, week); }
      catch (err) {
        if (err instanceof UserError) { if (!awardsWaiting.has(week)) { awardsWaiting.add(week); console.log(`[auto-potw] week ${week}: ${err.message}`); } continue; }
        throw err;
      }
      console.log(`[auto-potw] posted Player of the Week for week ${week}`);
      return { posted: true, week };
    }
  } catch (err) { if (!(err instanceof UserError)) console.error("[auto-potw]", err.message || err); }
  return result;
}

function start(client) {
  if (String(process.env.AUTO_POTW ?? "true").toLowerCase() === "false") return;
  if (!cfg.POTW_CHANNEL_ID) { console.log("[auto-potw] POTW_CHANNEL_ID is not set, so automatic posting is OFF (/auto-potw still works)."); return; }
  setTimeout(() => autoPotwTick(client), 60 * 1000).unref?.();
  setInterval(() => autoPotwTick(client), 15 * 60 * 1000).unref?.();
  console.log("[auto-potw] automatic Player of the Week is ON");
}

// ------------------------------------------------------------ /auto-potw
const COMMAND_NAMES = ["auto-potw"];
async function handleCommand(i) {
  if (!isAdmin(i)) return i.reply({ content: "You must be an administrator to use this command.", ephemeral: true });
  await i.deferReply({ ephemeral: true });
  try {
    const week = i.options.getInteger("week") || (await getCurrent()).week;
    if (!week) throw new UserError("I couldn't tell which week the league is on. Add the week number, e.g. `week: 5`.");
    const { sent, picked } = await postPotw(i.client, week, { force: i.options.getBoolean("force") || false, fallbackChannel: i.channel });
    return i.editReply(`✅ Posted Player of the Week for week ${week} in <#${sent.channelId}> (${picked.map(p => p.name).join(", ")}).`);
  } catch (err) {
    if (err instanceof UserError) return i.editReply(`⚠️ ${err.message}`);
    console.error("[auto-potw]", err);
    return i.editReply(`❌ Something went wrong: ${describeError(err).slice(0, 300)}`);
  }
}
const ownsComponent = () => false;
async function handleComponent() { return false; }

module.exports = { COMMAND_NAMES, handleCommand, handleComponent, ownsComponent, start, autoPotwTick, postPotw, buildPotw, UserError, _internal: { ownerOfTeam } };
