// Prospect Maker — ported from the FDL bot (3-step modal flow, same post format).
// TML posts to its own channel and saves to TML's own data/prospects.json.
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require("discord.js");
const cfg = require("./config");
const { readJson, writeJson } = require("./store");
const { isAdmin } = require("./util");
const prospectStats = require("./prospectStats");

const store = readJson("prospects", { prospects: [] });
// Existing prospects become scoutable after an upgrade, without reposting old sheets.
prospectStats.backfillProspects(store.prospects);
const sessions = new Map();

function modalField(id, label, placeholder, required = true, style = TextInputStyle.Short, max = 100) {
  return new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId(id).setLabel(label).setPlaceholder(placeholder || "").setStyle(style).setRequired(required).setMaxLength(max));
}
function getFields(i, ids) { const o = {}; for (const id of ids) o[id] = (i.fields.getTextInputValue(id) || "").trim(); return o; }

const COMMAND_NAMES = ["prospect-maker"];
async function handleCommand(i) {
  if (!isAdmin(i)) return i.reply({ content: "You must be an administrator to use this command.", ephemeral: true });
  const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId("prospect_make").setLabel("Make Now").setStyle(ButtonStyle.Primary));
  await i.channel.send({ content: "**Create your prospect!**", components: [row] });
  return i.reply({ content: "Prospect Maker posted.", ephemeral: true });
}

const ownsComponent = id => id === "prospect_make" || /^prospect(_continue2|_continue3|1|2|3):/.test(id);

async function handleComponent(i) {
  try {
    if (i.isButton()) {
      if (i.customId === "prospect_make") {
        sessions.set(i.user.id, { data: {}, startedAt: Date.now() });
        const m = new ModalBuilder().setCustomId(`prospect1:${i.user.id}`).setTitle("Prospect Maker — Basic");
        m.addComponents(modalField("name", "Name", "Player name"), modalField("college", "College", "College"), modalField("position", "Position", "QB, WR, EDGE, etc."), modalField("height", "Height", "Example: 6'3\""), modalField("weight", "Weight", "Example: 205 lbs"));
        return i.showModal(m);
      }
      const [kind, id] = i.customId.split(":");
      if (id !== i.user.id) return i.reply({ content: "This prospect form belongs to another user.", ephemeral: true });
      if (!sessions.get(id)) return i.reply({ content: "Your prospect session expired. Click Make Now to start a fresh form.", ephemeral: true });
      if (kind === "prospect_continue2") {
        const m = new ModalBuilder().setCustomId(`prospect2:${id}`).setTitle("Prospect Maker — Traits");
        m.addComponents(modalField("archetype", "Archetype", "Example: Power Rusher, Deep Threat"), modalField("strength1", "⭐ Strength 1", "Strength 1"), modalField("strength2", "⭐ Strength 2", "Strength 2"), modalField("weakness1", "⚠️ Weakness 1", "Weakness 1"), modalField("weakness2", "⚠️ Weakness 2", "Weakness 2"));
        return i.showModal(m);
      }
      if (kind === "prospect_continue3") {
        const m = new ModalBuilder().setCustomId(`prospect3:${id}`).setTitle("Prospect Maker — Final");
        m.addComponents(modalField("age", "Age", "Example: 21"), modalField("number", "Number (optional)", "Example: 12", false, TextInputStyle.Short, 10), modalField("backstory", "📖 Backstory (optional)", "Optional backstory", false, TextInputStyle.Paragraph, 1000), modalField("comparison", "Player Comparison", "NFL player comparison"));
        return i.showModal(m);
      }
    }
    if (i.isModalSubmit()) {
      const [kind, id] = i.customId.split(":");
      const s = sessions.get(id);
      if (id !== i.user.id) return i.reply({ content: "This prospect form belongs to another user.", ephemeral: true });
      if (!s) return i.reply({ content: "Your prospect session expired. Click Make Now to start a new one.", ephemeral: true });
      if (kind === "prospect1") {
        Object.assign(s.data, getFields(i, ["name", "college", "position", "height", "weight"]));
        const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`prospect_continue2:${id}`).setLabel("Continue to Traits").setStyle(ButtonStyle.Primary));
        return i.reply({ content: "**Step 1 saved.** Click **Continue to Traits** to enter the archetype, two strengths, and two weaknesses.", components: [row], ephemeral: true });
      }
      if (kind === "prospect2") {
        Object.assign(s.data, getFields(i, ["archetype", "strength1", "strength2", "weakness1", "weakness2"]));
        const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`prospect_continue3:${id}`).setLabel("Continue to Final Step").setStyle(ButtonStyle.Primary));
        return i.reply({ content: "**Step 2 saved.** Click **Continue to Final Step** to enter the age, optional number, optional backstory, and player comparison.", components: [row], ephemeral: true });
      }
      if (kind === "prospect3") {
        Object.assign(s.data, getFields(i, ["age", "number", "backstory", "comparison"]));
        const d = s.data;
        const required = ["name", "college", "position", "age", "height", "weight", "archetype", "strength1", "strength2", "weakness1", "weakness2", "comparison"];
        if (required.some(k => !d[k])) { sessions.delete(id); return i.reply({ content: "A required prospect field was missing. Click Make Now to start again.", ephemeral: true }); }
        const text = [`**${d.name}**`, `College: ${d.college}`, `Position: ${d.position}`, `Age: ${d.age}`, `Number: ${d.number || "N/A"}`, `Height: ${d.height}`, `Weight: ${d.weight}`, `Archetype: ${d.archetype}`, "", `⭐ Strength: ${d.strength1}`, `⭐ Strength: ${d.strength2}`, "", `⚠️ Weakness: ${d.weakness1}`, `⚠️ Weakness: ${d.weakness2}`, "", `📖 Backstory (optional): ${d.backstory || "N/A"}`, "", `Player Comparison: ${d.comparison}`].join("\n");
        const ch = await i.client.channels.fetch(cfg.PROSPECT_CHANNEL_ID).catch(() => null);
        if (!ch?.isTextBased()) throw new Error(`Prospect channel ${cfg.PROSPECT_CHANNEL_ID} is missing or not a text channel.`);
        const perms = ch.permissionsFor?.(i.guild.members.me);
        if (perms && !perms.has(["ViewChannel", "SendMessages"])) throw new Error(`Bot lacks View Channel and/or Send Messages in <#${cfg.PROSPECT_CHANNEL_ID}>.`);
        const sent = await ch.send({ content: text.slice(0, 2000), allowedMentions: { parse: [] } });
        const sheet = prospectStats.createProspectSheet(d, { channelId: ch.id, messageId: sent.id, userId: id });
        store.prospects.push({ userId: id, username: i.user.username, channelId: ch.id, messageId: sent.id, sheetId: sheet.id, data: d, createdAt: new Date().toISOString() });
        writeJson("prospects", store);
        sessions.delete(id);
        try {
          await prospectStats.publishProspectSheet(i.client, sheet, cfg.PROSPECT_STATS_CHANNEL_ID);
        } catch (sheetError) {
          console.error("Prospect stat-sheet post error:", sheetError);
          return i.reply({ content: `Your prospect was posted in <#${ch.id}> and the stat sheet was saved, but I couldn't post it in <#${cfg.PROSPECT_STATS_CHANNEL_ID}>: ${sheetError.message}`, ephemeral: true });
        }
        return i.reply({ content: `Your prospect was posted in <#${ch.id}> and its randomized stat sheet was posted in <#${cfg.PROSPECT_STATS_CHANNEL_ID}>.`, ephemeral: true });
      }
    }
  } catch (e) {
    console.error("Prospect Maker error:", e);
    sessions.delete(i.user.id);
    const msg = `Prospect Maker error: ${e.message || "unknown error"}. Your form was reset; click Make Now to start again.`;
    if (i.isRepliable() && !i.replied && !i.deferred) await i.reply({ content: msg, ephemeral: true }).catch(() => {});
  }
  return false;
}

module.exports = { COMMAND_NAMES, handleCommand, handleComponent, ownsComponent };
