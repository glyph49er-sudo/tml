const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const A = PermissionFlagsBits.Administrator, MR = PermissionFlagsBits.ManageRoles;

const commands = [
  // ---- Team Claimer (only the commands requested for TML)
  new SlashCommandBuilder().setName("setup-nfl-teams").setDescription("Create/link all 32 TML NFL team roles and post the claim buttons here.")
    .addBooleanOption(o => o.setName("create-missing").setDescription("Create any team role that doesn't exist yet (default: true)").setRequired(false))
    .addBooleanOption(o => o.setName("post-panels").setDescription("Post the AFC/NFC claim buttons in this channel (default: true)").setRequired(false))
    .setDefaultMemberPermissions(MR),
  new SlashCommandBuilder().setName("sync-teams").setDescription("Re-scan the server so whoever holds each team role owns that team.").setDefaultMemberPermissions(MR),
  new SlashCommandBuilder().setName("my-team").setDescription("Show which team you have claimed."),
  new SlashCommandBuilder().setName("release-member").setDescription("Remove a member's claimed team so they can pick again.")
    .addUserOption(o => o.setName("member").setDescription("The member to reset").setRequired(true)).setDefaultMemberPermissions(MR),
  new SlashCommandBuilder().setName("release-team").setDescription("Free up a team so somebody else can claim it.")
    .addRoleOption(o => o.setName("role").setDescription("The team role to release").setRequired(true)).setDefaultMemberPermissions(MR),
  new SlashCommandBuilder().setName("waitlist-button").setDescription("Admin: post the Join the waitlist button.").setDefaultMemberPermissions(A),

  // ---- Prospect Maker and persistent scouting
  new SlashCommandBuilder().setName("prospect-maker").setDescription("Post the prospect maker button.").setDefaultMemberPermissions(A),
  new SlashCommandBuilder().setName("scout-player").setDescription("Reveal one position-based rating for a generated prospect (one use per two-day window).")
    .addStringOption(o => o.setName("player").setDescription("Prospect's full name").setRequired(true).setMaxLength(100)),
  new SlashCommandBuilder().setName("scout-sheet").setDescription("Show every prospect rating and development trait you have revealed."),
  new SlashCommandBuilder().setName("reset-scout-sheets").setDescription("Admin: wipe everyone's revealed scout information and use limits.").setDefaultMemberPermissions(A),

  // ---- Awards
  (() => {
    const b = new SlashCommandBuilder().setName("player-of-the-week").setDescription("Post Player of the Week for exactly four winners.")
      .addStringOption(o => o.setName("week").setDescription("Week number").setRequired(true).setMaxLength(10));
    for (const n of [1, 2, 3, 4]) b.addUserOption(o => o.setName(`winner${n}`).setDescription(`Winner ${n}`).setRequired(true));
    return b.setDefaultMemberPermissions(A);
  })(),
  new SlashCommandBuilder().setName("game-of-the-week").setDescription("Post Game of the Week from the FRANCHISE HUB result.")
    .addStringOption(o => o.setName("week").setDescription("Week number").setRequired(true).setMaxLength(10))
    .addUserOption(o => o.setName("winner").setDescription("The winning Discord user").setRequired(true))
    .addStringOption(o => o.setName("reason").setDescription("Optional: why this is Game of the Week").setRequired(false).setMaxLength(1000))
    .setDefaultMemberPermissions(A),

  new SlashCommandBuilder().setName("auto-potw").setDescription("Admin: post this week's Player of the Week from Madden's weekly awards.")
    .addIntegerOption(o => o.setName("week").setDescription("Week number (default: current week)").setMinValue(1).setMaxValue(23))
    .addBooleanOption(o => o.setName("force").setDescription("Post again even if this week was already posted"))
    .setDefaultMemberPermissions(A),

  // ---- Madden link (EA connection)
  new SlashCommandBuilder().setName("ea-connect").setDescription("Admin: connect TML directly to the Madden 27 PC franchise through EA.").setDefaultMemberPermissions(A),
  new SlashCommandBuilder().setName("ea-status").setDescription("Admin: show the Madden EA connection and last franchise sync.").setDefaultMemberPermissions(A),
  new SlashCommandBuilder().setName("ea-refresh").setDescription("Admin: immediately refresh the Madden franchise data.").setDefaultMemberPermissions(A),
  new SlashCommandBuilder().setName("ea-disconnect").setDescription("Admin: remove TML's saved EA connection.").setDefaultMemberPermissions(A),

  // ---- Mystery Box
  new SlashCommandBuilder().setName("mystery-box-post").setDescription("Admin: post the daily Mystery Box roll button.").setDefaultMemberPermissions(A),
  new SlashCommandBuilder().setName("mystery-box-checker").setDescription("Admin: see Mystery Box rewards by user and date.")
    .addUserOption(o => o.setName("user").setDescription("Only this user").setRequired(false))
    .addStringOption(o => o.setName("date").setDescription("Only this Pacific date, e.g. 2026-11-12").setRequired(false))
    .setDefaultMemberPermissions(A)
];

module.exports = { commands, commandJson: () => commands.map(c => c.toJSON()) };
