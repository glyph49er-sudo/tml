// Pre-flight check: syntax of every JS file, commands <-> handlers, probabilities.
const { execFileSync } = require("node:child_process");
const fs = require("node:fs"); const path = require("node:path");
const root = path.join(__dirname, "..");
const files = [];
(function walk(d) { for (const f of fs.readdirSync(d)) { if (["node_modules", "data", ".git"].includes(f)) continue; const p = path.join(d, f); if (fs.statSync(p).isDirectory()) walk(p); else if (p.endsWith(".js")) files.push(p); } })(root);
for (const f of files) execFileSync(process.execPath, ["--check", f]);
console.log(`✔ Syntax OK in ${files.length} files`);
process.env.TML_DATA_DIR = fs.mkdtempSync(path.join(require("node:os").tmpdir(), "tml-check-"));
const { commandJson } = require("../src/commands");
const mods = ["teamClaimer", "prospect", "scouting", "awards", "mysteryBox", "eaLink", "autoPotw"].map(m => require(`../src/${m}`));
const handled = new Set(mods.flatMap(m => m.COMMAND_NAMES));
const registered = commandJson().map(c => c.name);
const unhandled = registered.filter(n => !handled.has(n)), unregistered = [...handled].filter(n => !registered.includes(n));
if (unhandled.length || unregistered.length) { console.error("✘ Command mismatch", { unhandled, unregistered }); process.exit(1); }
console.log(`✔ ${registered.length} slash commands registered, each with a handler: ${registered.map(n => "/" + n).join(" ")}`);
const ids = ["waitlist:join", "claim:1", "prospect_make", "prospect1:1", "prospect_continue2:1", "prospect2:1", "prospect_continue3:1", "prospect3:1", "potw_claim:x", "potw_modal:x", "gotw_claim:x", "gotw_attr:x:o", "gotw_modal:x:o:0", "mbox_roll", "mbox_apply:d", "mbox_modal:d", "ea:begin:1", "eaCode:1", "eaPersona:1", "eaLeague:1", "eaRetryLeagues:1"];
for (const id of ids) { const owners = mods.filter(m => m.ownsComponent?.(id)); if (owners.length !== 1) { console.error(`✘ ${id} has ${owners.length} handlers`); process.exit(1); } }
console.log(`✔ ${ids.length} button/menu/modal ids each have exactly one handler`);
const mb = require("../src/mysteryBox");
console.log(`✔ Mystery Box total = ${mb.TOTAL_TENTHS / 10}%`);
